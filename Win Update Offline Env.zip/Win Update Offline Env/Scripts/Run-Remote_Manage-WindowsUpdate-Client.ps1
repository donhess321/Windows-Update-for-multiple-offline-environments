﻿# Run a PS script file over a remote connection.
param (
	[switch] $DownloadOfflineDb, 
	[switch] $ApplyUpdatesOffline, 
	[switch] $ApplyUpdatesOffline_wReboot, 
	[switch] $ApplyUpdatesOnline, 
	[switch] $CheckForUpdatesOffline, 
	[switch] $CheckForUpdatesOnline, 
	[switch] $InstalledUpdates, 
	[array] $Computers = @(), 
	[switch] $DoItFast
)

Set-StrictMode -Version latest -Verbose
$ErrorActionPreference = 'Stop'
$PSDefaultParameterValues['*:ErrorAction']='Stop'

if ( -not $Computers ) {
    # Get a listing of all workstations
    #$sDomainSnip = (Get-WmiObject Win32_ComputerSystem).Domain.Trim().Substring(0,3)
    $aComputers = Get-ADComputer -Filter * | Select-Object Name,DNSHostName,Enabled | `
        Where-Object { $_.Enabled -and $_.Name -Like "WKNAME*" -and $null -ne $_.DNSHostName } | `
        ForEach-Object { $_.Name } | Sort
} else {
    # Something passed in
    $aComputers = $Computers
}

# These need to be the parameters AS FULL strings
# They are the names of the tasks on the clients
$aParams = @()
if ( $DownloadOfflineDb.IsPresent ) {
    $aParams += 'WinUpdate-DownloadOfflineDb'
}
if ( $ApplyUpdatesOffline.IsPresent ) {
    $aParams += 'WinUpdate-ApplyUpdates-Offline'
}
if ( $ApplyUpdatesOffline_wReboot.IsPresent ) {
    $aParams += 'WinUpdate-ApplyUpdatesOffline_wReboot'
}
if ( $ApplyUpdatesOnline.IsPresent ) {
    $aParams += 'WinUpdate-ApplyUpdates-Online'
}
if ( $CheckForUpdatesOffline.IsPresent ) {
    $aParams += 'WinUpdate-CheckForUpdates-Offline'
}
if ( $CheckForUpdatesOnline.IsPresent ) {
    $aParams += 'WinUpdate-CheckForUpdates-Online'
}
if ( $InstalledUpdates.IsPresent ) {
    $aParams += 'WinUpdate-InstalledUpdates'
}

$sb1 = {
    param ($sTaskName) # Param for the scriptblock input
    $TASK_STATE = @{0 = "Unknown"; 1 = "Disabled"; 2 = "Queued"; 3 = "Ready"; 4 = "Running"}
    $ACTION_TYPE = @{0 = "Execute"; 5 = "COMhandler"; 6 = "Email"; 7 = "ShowMessage"}
    # Try to create the TaskService object on the local computer; throw an error on failure
    try {
        $TaskService = New-Object -ComObject "Schedule.Service"
    } catch [System.Management.Automation.PSArgumentException] {
        throw $_
    }
    Write-Host "Starting task '$sTaskName' "
    $TaskService.Connect()
    $oSingleTask = ($TaskService.GetFolder('\')).GetTask($sTaskName)
    if ( ($oSingleTask.State -eq 2) -or ($oSingleTask.State -eq 3) ) {
        $oSingleTask.Run('') | Out-Null
    }
} # End sb1

$aFormattedParams = &{ $args } @aParams
# The `.{}` statement could be replaced with `&{}` here, because we don't need to persist variables after script call.
$sScriptBlockContent = "&{ $sb1 } $aFormattedParams"
$sbFinal = [scriptblock]::create($sScriptBlockContent)
if ($DoItFast) {
$iTime = 1
} else {
$iTime = 30
}
$aComputers | ForEach-Object {
    $sCompName = $_
    Write-Host "Working on host $_ "
    # When calling a Sched Task, the command returns immediately
    Invoke-Command -ThrottleLimit 1 -ComputerName $sCompName -ScriptBlock $sbFinal -ErrorAction Continue
    if ( $aComputers.Count -gt 1 ) {
        Write-Host "Waiting $iTime seconds to stagger client connections"
        Sleep $iTime
    }
}
# $Cred = Get-Credential
#Invoke-Command -ComputerName '' -Credential $Cred -ScriptBlock $sbFinal

#$session = New-PSSession -ComputerName '' -Credential $Cred
#Invoke-Command -Session $session -ScriptBlock $sbFinal
#Remove-PSSession $session

