<# 
.SYNOPSIS
    Get the Windows Updates XML files from each computer
.DESCRIPTION  
    Get the Windows Updates XML files from each computer.  The most current needed updates, 
    failed downloaded updates, and log file is copied from each computer to a centralized location.
    This must be run from a server on the domain as it accesses the administrative C$ share.
.OUTPUTS
    A merged XML file for needed updates and another for failed downloads to the same location 
    as each source folder.  A summary CSV file about all computer's needed updates.
.EXAMPLE
    Get-WindowsUpdate-ClientResults
    Will use the array of computer names listed in the script.  No logging will occur.
.EXAMPLE
    Get-WindowsUpdate-ClientResults -Computers ",comp1" -l default
    Array with single computer name.  Logging will be to the default location of the users temp folder
.EXAMPLE
    Get-WindowsUpdate-ClientResults -Computers @("comp1") -l default
    Array with single computer name.  Logging will be to the default location of the users temp folder
.EXAMPLE
    Get-WindowsUpdate-ClientResults -Computers "comp1,comp2,comp3" -l '\\server\share\logfile.txt
    Will use the array of computer names listed in the script.  No logging will occur.
.NOTES
    Author: Don Hess
    Version History:
    1.0    2019-07-11   Release for PS v2+
.LINK
    NA
#> 
[CmdletBinding()]
param (
    [Parameter(Mandatory=$false,
               Position=1,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage="Array of client computer names")]  
    [array] $Computers = @(),

    [Parameter(Mandatory=$false,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               Position=2,
               HelpMessage="Full path to log file.  Enter 'default' to log to the local temp directory")]
    [ValidateNotNullOrEmpty()]
    [string] $l = '--'
)

Set-StrictMode -Version latest -Verbose
$ErrorActionPreference = 'Stop'
######################### Begin User Variables #####################################
$sScriptName = "Get-WindowsUpdate-ClientResults.ps1"
# Where is each client's install root for the Windows Update scripts?
# MUST be in the Admin share format.  No lead or trailing slashes
$sClientInstallRoot = 'C$\ProgramFiles2\WinUpdateScripts'
# Destination root for all of the copied files from the clients
$sServerStorRoot = '\\myservername\S1\workstation_uploads\windows_updates'
# All the computers to collect update results from
# This is overridden if -Computers parameter is specified
$aComputers = @(  
     'mycompname'
)
$sMergedUpdatesNeededFileName = 'UpdatesNeeded-Merged.xml'  # Output file
$sMergedFailedDownloadFileName = 'UpdatesThatFailedDownload-Merged.xml'  # Output file
$sMergedInstalledUpdatesFileName = 'InstalledUpdates-Merged.html'  # Output file
# Logging options
$bolEnableDisplayToScreen = $true  # Usually turned on all the time
######################### End User Variables #######################################

$oMain = New-Object -TypeName System.Management.Automation.PSObject
Add-Member -InputObject $oMain -MemberType NoteProperty -Name ScriptName -Value $sScriptName
Add-Member -InputObject $oMain -MemberType NoteProperty -Name CompName -Value $env:computername

$sbMethWriteToLog = {
    # Method to write to the log file.
    Param ([string[]] $Msg = '')
    try {
        if ($this.EnableLogging) {
            Out-File -Filepath $this.LogFileFullName -Inputobject $Msg -Append -ErrorAction SilentlyContinue
        }
    } catch {
        $err = $_
        throw $err
    }
}
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name WriteToLog -Value $sbMethWriteToLog
$sbMethDisplayToScreen = {
    # Method to display to screen
    Param ([string[]] $Msg = '')
    if ($this.EnableDisplay) {
        Write-Host $Msg
    }
}
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name DisplayToScreen -Value $sbMethDisplayToScreen
$sbIsoDateLocal = {Get-Date -uformat "%Y-%m-%dT%T%Z"} # ISO 8601 format 2016-08-23T22:10:45+05
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name GetDateTime_Iso -Value $sbIsoDateLocal
$sbDtTodayUnderScr = {Get-Date -uformat "%Y-%m-%d_%I_%M_%S_%p"} # YYYY-MM-DD HH-MM-SS AM/PM  
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name GetDateTime_UnderScr -Value $sbDtTodayUnderScr

if ( $Computers.count -ne 0 ) {
    # Something passed in
    $aComputers = $Computers
}
# l  Log file with full path.  This must be processes before -file
# Check for illegal characters / ? < > * | ' " { } ;
$sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
$regex1 = [regex] $sTemp
if ( $l -match $regex1 ) {
    throw [System.ArgumentException] 'Log file input has invlid character(s)' 
}
switch ( $l.ToLower() ) {
    '--' {
        $bolEnableLogging = $false
        $sLogFileFullNameFinal = $l
        break
    }
    'default' {
        # Logging is to be done to the default local temp directory
        $sExt = '.txt'
        $sDtTemp = Invoke-Command -ScriptBlock $sbDtTodayUnderScr
        $sLogFileFullNameFinal = @($env:Temp,"\Log",'_',$sDtTemp,$sExt) -join ''
        $bolEnableLogging = $true
        break
    }
    default {
        # We have some file to log to
        # The Split-Path auto handles the tailing \ on a directory 
        $sDirPath = Split-Path -Parent $l                      # Log file Path only
        $sFileNameWExt = Split-Path -Leaf $l            # Log file Name with extention
        $sExt = '.txt'
        if ( $sFileNameWExt -match "(?<Extension>\.log$|\.txt$)" ) {
            $sFileName = $sFileNameWExt.Remove($sFileNameWExt.length - 4)
            $sExt = $matches.Extension
        } else {
            $sFileName = $sFileNameWExt
        }
        $sDtTemp = Invoke-Command -ScriptBlock $sbDtTodayUnderScr
        $sLogFileFullNameFinal = @($sDirPath,'\',$sFileName,'_',$sDtTemp,$sExt) -join ''
        $bolEnableLogging = $true
        break
    }
}
Add-Member -InputObject $oMain -MemberType NoteProperty -Name LogFileFullName -Value $sLogFileFullNameFinal
Add-Member -InputObject $oMain -MemberType NoteProperty -Name EnableLogging -Value $bolEnableLogging
Add-Member -InputObject $oMain -MemberType NoteProperty -Name EnableDisplay -Value $bolEnableDisplayToScreen
Add-Member -InputObject $oMain -MemberType NoteProperty -Name CompUpdateResults -Value @()
Add-Member -InputObject $oMain -MemberType NoteProperty -Name CabFileInfoResults -Value @()
function funcStringIsNullOrWhitespace([string] $string) {
    if ($null -ne $string) { $string = $string.Trim() }
    return [string]::IsNullOrEmpty($string)
}
function funcCreateFolderPath( [string] $sPathIn ) {
    <#  .DESCRIPTION
             Create an entire Windows folder path one folder at a time
        .PARAMETER sPathIn
             String containing the full path to the folder.  
             Accepts local or remote servers.  
                C:\  C:\myfolder1   \\server\share  \\server\share\myfolder1
                '~'  '~\new1\new2'  (empty str)   '.'  '.\'  '.\new1\new2'
        .OUTPUTS
            Directory object of the last folder created
    #>
    if ( $sPathIn -eq '' ) {  # Empty string, get current path
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    if ( $sPathIn -eq '.' ) { # Current path only
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    # Check for illegal characters  / ? < > * | ' " { } ;   Allows  c:\  \\server
    $sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( ($sPathIn -match $regex1) -or (funcStringIsNullOrWhitespace $sPathIn) ) {
        $textOut1 = "Folder path '{0}' has illegal character(s)" -f @($sPathIn)
        throw [System.ArgumentException] $textOut1
    }
    if ( Test-Path -PathType Container -Path $sPathIn ) {
        $oTempPath = Get-Item -Path $sPathIn
        return ,$oTempPath
    }
    $oTempPath = New-Item -Path $sPathIn -Type Directory
    return ,$oTempPath
} # End funcCreateFolderPath
function funcComputerResultsFactory() {
        $oReturned = New-Object -TypeName System.Management.Automation.PSObject
        # These fields will be added to the object in this order.  They will also export to CSV in the order defined here.
        #Add-Member -InputObject $oReturned -MemberType NoteProperty  -Name "TestDateTime_UtcString" -Value $dtNow.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.ffffffZ")
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name "FileName_XML" -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name "FileDateTime_XML" -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name "NumOfUpdatesNeeded" -Value $null
        return ,$oReturned
}
function funcImportSingleXmlUpdateRequirement( [string] $path ) {
    $oImported = Import-Clixml -Path $path
    if ( $oImported.gettype().Name -eq 'Hashtable' ) {
        return ,$oImported
    } else {
        $textOut = "Type Exception: Imported object is not hashtable.  Type is: '{0}'" -f @($oImported.gettype().Name)
        throw $textOut
    }
}
function funcMergeAndExportUpdateRequirements( [string] $sSourceFolder, [string] $sOutputFileName ) {
    <#  .DESCRIPTION
             Import each computers UpdatesNeeded XML file, merge into a single result, and export to an XML file.
             All XML files must be of the same type (no mix/match)
        .PARAMETER sSourceFolder
             String containing the full path to the folder full of XML files to be read  
        .PARAMETER sOutputFileName
            String for the merged XML file output (just file name, no path)
        .OUTPUTS
            Returns file object of export that is located in the same diretory as sSourceFolder
            Loads $oMain.CompUpdateResults with information about each XML file imported
        .NOTES
            Needs access to $oMain.CompUpdateResults and $oMain for logging/display
            Needs access to funcImportSingleXmlUpdateRequirement and funcComputerResultsFactory
    #>
    $oSourceFolder = Get-Item -Path $sSourceFolder
    $htAllUpdatesRequired = @{}
    $oMain.CompUpdateResults = @()
    Get-ChildItem $oSourceFolder | Where-Object { -not $_.PSIsContainer } | Where-Object { $_.Extension -eq '.xml' } | ForEach-Object {
        $oFile = $_
        $htSingle = funcImportSingleXmlUpdateRequirement $oFile.FullName
        $oSingleCompResult = funcComputerResultsFactory
        $oSingleCompResult.FileName_XML = $oFile.Name
        $oSingleCompResult.FileDateTime_XML = $oFile.LastWriteTime
        $oSingleCompResult.NumOfUpdatesNeeded = $htSingle.Count
        $oMain.CompUpdateResults += $oSingleCompResult  # Save out the object somewhere safe
        foreach ( $oItem in $htSingle.GetEnumerator() ) {
            $htAllUpdatesRequired.Set_Item($oItem.Name,$oItem.Value)
        }
        if ( $htSingle.Count -eq 0 ) {
            $textOut1 = "{0}  {1} {2} File '{3}' does not require any updates" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile.Name)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
        }
    }
    $sOutputFileFullName = @($oSourceFolder.FullName,'\',$sOutputFileName) -join ''
    # Destination directory is the same as the source and should have been cleaned during script startup
    Export-Clixml -Force -Confirm:$false -Depth 300 -InputObject $htAllUpdatesRequired -Path $sOutputFileFullName
    $oFile = Get-Item -LiteralPath $sOutputFileFullName
    return ,$oFile
}
function funcImportCabFileInfoXml( [string] $sSourceFolder ) {
    <#  .DESCRIPTION
             Import each computers CabFileInfo XML file, attach to main object.
             All XML files must be of the same type (no mix/match)
        .PARAMETER sSourceFolder
             String containing the full path to the folder full of XML files to be read  
        .OUTPUTS
            Loads $oMain.CabFileInfoResults with information about each XML file imported
        .NOTES
            Needs access to $oMain.CabFileInfoResults and $oMain for logging/display.
            The information in the XML is about the file that was extracted from the original CAB file.  
            It tells us the date that the cab file was created and last written to.
            No need to validate XML file input because it is not fed to any other part of script.
    #>
    $oSourceFolder = Get-Item -Path $sSourceFolder
    $oMain.CabFileInfoResults = @()
    Get-ChildItem $oSourceFolder | Where-Object { -not $_.PSIsContainer } | Where-Object { $_.Extension -eq '.xml' } | ForEach-Object {
        $oMain.CabFileInfoResults += (Import-Clixml -Path $_.FullName)  # Save out the object somewhere safe
    }
}
function funcConvertTo-DataTable {
    <#  .SYNOPSIS
            Convert regular PowerShell objects to a DataTable object.
        .DESCRIPTION
            Convert regular PowerShell objects to a DataTable object.
        .EXAMPLE
            $myDataTable = $myObject | ConvertTo-DataTable
        .NOTES
            Name: ConvertTo-DataTable
            Author: Oyvind Kallstad @okallstad
            Version: 1.1
    #>
    [CmdletBinding()]
    param (
        # The object to convert to a DataTable
        [Parameter(ValueFromPipeline = $true)]
        [PSObject[]] $InputObject,

        # Override the default type.
        [Parameter()]
        [string] $DefaultType = 'System.String'
    )
    begin {
        # Create an empty datatable
        try {
            $dataTable = New-Object -TypeName 'System.Data.DataTable'
            Write-Verbose -Message 'Empty DataTable created'
        } catch {
            Write-Warning -Message $_.Exception.Message
            break
        }
        # Define a boolean to keep track of the first datarow
        $first = $true
        # Define array of supported .NET types
        $types = @(
            'System.String',
            'System.Boolean',
            'System.Byte[]',
            'System.Byte',
            'System.Char',
            'System.DateTime',
            'System.Decimal',
            'System.Double',
            'System.Guid',
            'System.Int16',
            'System.Int32',
            'System.Int64',
            'System.Single',
            'System.UInt16',
            'System.UInt32',
            'System.UInt64'
        )
    }
    process {
        # Iterate through each input object
        foreach ($object in $InputObject) {
            try {
                # Create a new datarow
                $dataRow = $dataTable.NewRow()
                Write-Verbose -Message 'New DataRow created'
                # Iterate through each object property
                foreach ($property in $object.PSObject.get_properties()) {
                    # Check if we are dealing with the first row or not
                    if ($first) {
                        # handle data types
                        if ($types -contains $property.TypeNameOfValue) {
                            $dataType = $property.TypeNameOfValue
                            Write-Verbose -Message "$($property.Name): Supported datatype <$($dataType)>"
                        } else {
                            $dataType = $DefaultType
                            Write-Verbose -Message "$($property.Name): Unsupported datatype ($($property.TypeNameOfValue)), using default <$($DefaultType)>"
                        }
                        # Create a new datacolumn
                        $dataColumn = New-Object 'System.Data.DataColumn' $property.Name, $dataType
                        Write-Verbose -Message 'Created new DataColumn'

                        # Add column to DataTable
                        $dataTable.Columns.Add($dataColumn)
                        Write-Verbose -Message 'DataColumn added to DataTable'
                    }                  
                    # Add values to column
                    if ($property.Value -ne $null) {
                        # If array or collection, add as XML
                        if (($property.Value.GetType().IsArray) -or ($property.TypeNameOfValue -like '*collection*')) {
                            $dataRow.Item($property.Name) = $property.Value | ConvertTo-Xml -As 'String' -NoTypeInformation -Depth 1
                            Write-Verbose -Message 'Value added to row as XML'
                        } else {
                            $dataRow.Item($property.Name) = $property.Value -as $dataType
                            Write-Verbose -Message "Value ($($property.Value)) added to row as $($dataType)"
                        }
                    }
                }
                # Add DataRow to DataTable
                $dataTable.Rows.Add($dataRow)
                Write-Verbose -Message 'DataRow added to DataTable'
                $first = $false
            } catch {
                Write-Warning -Message $_.Exception.Message
            }
        }
    }
    end { Write-Output (,($dataTable)) }
} # End funcConvertTo-DataTable

################################ MAIN ################################
######################################################################
$oMain.WriteToLog($oMain.GetDateTime_Iso()+'  Test write to log')
$textOut1 = "Computer: {0}" -f @($oMain.CompName)
$oMain.DisplayToScreen($textOut1)
$oMain.WriteToLog($oMain.GetDateTime_Iso()+'  '+$textOut1)

try {
    $textOut1 = "{0}  {1} {2} Creating folder structure on server storage" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);

    $sServerStorResultsPath = @($sServerStorRoot,'\','Results') -join ''
    $sServerStorLogsPath = @($sServerStorRoot,'\','Logs') -join ''
    funcCreateFolderPath (@($sServerStorResultsPath,'\','Needed') -join '') | Out-Null
    funcCreateFolderPath (@($sServerStorResultsPath,'\','Failed') -join '') | Out-Null
    funcCreateFolderPath (@($sServerStorResultsPath,'\','Installed') -join '') | Out-Null
    funcCreateFolderPath (@($sServerStorResultsPath,'\','CabFileInfo') -join '') | Out-Null
    funcCreateFolderPath $sServerStorLogsPath | Out-Null
    
    $textOut1 = "{0}  {1} {2} Cleaning out any existing client files" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    Get-ChildItem -Path (Resolve-Path ($sServerStorResultsPath+'\Needed')).Path | Remove-Item -Recurse -Force -Confirm:$false 
    Get-ChildItem -Path (Resolve-Path ($sServerStorResultsPath+'\Failed')).Path | Remove-Item -Recurse -Force -Confirm:$false
    Get-ChildItem -Path (Resolve-Path ($sServerStorResultsPath+'\Installed')).Path | Remove-Item -Recurse -Force -Confirm:$false 
    Get-ChildItem -Path (Resolve-Path ($sServerStorResultsPath+'\CabFileInfo')).Path | Remove-Item -Recurse -Force -Confirm:$false 
    
    Get-ChildItem -Path (Resolve-Path ($sServerStorLogsPath)).Path | Remove-Item -Recurse -Force -Confirm:$false 
} catch {
    $err = $_
    $textOut1 = "{0}  {1} {2} " -f @($oMain.GetDateTime_Iso(), $oMain.ScriptName, 'Script failure!')
    $textOut2 = "$textOut1 `n{0}`nLine: {1}: {2}" -f `
                @($err.Exception.Message
                 ,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim()
                 ,$err.get_InvocationInfo().Line.Trim())
    $oMain.DisplayToScreen($textOut2); $oMain.WriteToLog($textOut2)
    throw $err
}

try {
    # Copy all the results from the clients.  Need to separate the client's 'needed' from 'failed' from 'installed' results
    $aComputers | ForEach-Object {
        $sClientName = $_
        $iDaysAgo = 25
        $sClientResultsPath = @('\\',$sClientName,'\',$sClientInstallRoot,'\','Results') -join ''
        $sClientLogPath = @('\\',$sClientName,'\',$sClientInstallRoot,'\','Logs') -join ''
        # Create regex to identify different input file types
        $regUpdatesNeeded = [regex] (@('UpdatesNeeded-',$sClientName,'.xml') -join '').ToLower()
        $regUpdatesThatFailedDownload = [regex] (@('UpdatesThatFailedDownload-',$sClientName,'_.*\.xml') -join '').ToLower()
        $regInstalledUpdates = [regex] (@('InstalledUpdates-',$sClientName,'.xml') -join '').ToLower()
        $regCabFileInfo = [regex] (@('CabFileInformation-',$sClientName,'_.*\.xml') -join '').ToLower()

        $textOut1 = "{0}  {1} {2} Working on client {3}" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sClientName)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
        try {
            # Copy the 'NeededUpdates' xml file listing.  Need only the most recent.
            $oFile_MostRecent = Get-ChildItem -LiteralPath $sClientResultsPath | `
                Where-Object { $_.PSIsContainer -eq $false } | `
                Where-Object { $_.Name.ToLower() -match $regUpdatesNeeded } | `
                Sort-Object CreationTime -Descending | Select-Object -First 1 | `
                Where-Object { $_.CreationTime -gt (Get-Date).AddDays(0-$iDaysAgo) } 
            if ( $null -eq $oFile_MostRecent ) {
                $textOut1 = "{0}  {1} {2} Error: No UpdatesNeeded file exists for the last {3} days" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $iDaysAgo)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            } else {
                $textOut1 = "{0}  {1} {2} Copying file '{3}'" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile_MostRecent.FullName)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
                $oDest = Get-Item -LiteralPath (Resolve-Path ($sServerStorResultsPath+'\Needed')).path
                Copy-Item -LiteralPath $oFile_MostRecent.FullName -Destination $oDest
            }
            # Copy the 'FailedDownload' xml file listing resulting from misses on internal web server
            $oFile_MostRecent = Get-ChildItem -LiteralPath $sClientResultsPath | `
                Where-Object { $_.PSIsContainer -eq $false } | `
                Where-Object { $_.Name.ToLower() -match $regUpdatesThatFailedDownload } | `
                Sort-Object CreationTime -Descending | Select-Object -First 1 | `
                Where-Object { $_.CreationTime -gt (Get-Date).AddDays(0-$iDaysAgo) } 
            if ( $null -eq $oFile_MostRecent ) {
                # File doesn't need to exist, everything might have worked correctly
                Out-Null
            } else {
                $textOut1 = "{0}  {1} {2} Copying file '{3}'" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile_MostRecent.FullName)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
                $oDest = Get-Item -LiteralPath (Resolve-Path ($sServerStorResultsPath+'\Failed')).path
                Copy-Item -LiteralPath $oFile_MostRecent.FullName -Destination $oDest
            }
            # Copy the 'InstalledUpdates' xml file listing
            $oFile_MostRecent = Get-ChildItem -LiteralPath $sClientResultsPath | `
                Where-Object { $_.PSIsContainer -eq $false } | `
                Where-Object { $_.Name.ToLower() -match $regInstalledUpdates } | `
                Sort-Object CreationTime -Descending | Select-Object -First 1 | `
                Where-Object { $_.CreationTime -gt (Get-Date).AddDays(0-$iDaysAgo) } 
            if ( $null -eq $oFile_MostRecent ) {
                $textOut1 = "{0}  {1} {2} Error: No InstalledUpdates file exists for the last {3} days" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $iDaysAgo)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            } else {
                $textOut1 = "{0}  {1} {2} Copying file '{3}'" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile_MostRecent.FullName)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
                $oDest = Get-Item -LiteralPath (Resolve-Path ($sServerStorResultsPath+'\Installed')).path
                Copy-Item -LiteralPath $oFile_MostRecent.FullName -Destination $oDest
            }
            # Copy the 'CabFileInformation' xml file listing that contains info about the wsusscn2.cab file
            $oFile_MostRecent = Get-ChildItem -LiteralPath $sClientResultsPath | `
                Where-Object { $_.PSIsContainer -eq $false } | `
                Where-Object { $_.Name.ToLower() -match $regCabFileInfo } | `
                Sort-Object CreationTime -Descending | Select-Object -First 1 
            if ( $null -eq $oFile_MostRecent ) {
                $textOut1 = "{0}  {1} {2} Error: No CabFileInformation file exists" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $iDaysAgo)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            } else {
                $textOut1 = "{0}  {1} {2} Copying file '{3}'" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile_MostRecent.FullName)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
                $oDest = Get-Item -LiteralPath (Resolve-Path ($sServerStorResultsPath+'\CabFileInfo')).path
                Copy-Item -LiteralPath $oFile_MostRecent.FullName -Destination $oDest
            }
            # Copy log files
            $oFile_MostRecent = Get-ChildItem -LiteralPath $sClientLogPath | `
                Where-Object { $_.PSIsContainer -eq $false } | `
                #Where-Object { $_.Name.ToLower() -match $regUpdatesThatFailedDownload } | `
                Sort-Object CreationTime -Descending | Select-Object -First 1 | `
                Where-Object { $_.CreationTime -gt (Get-Date).AddDays(0-$iDaysAgo) } 
            if ( $null -eq $oFile_MostRecent ) {
                $textOut1 = "{0}  {1} {2} Error: No log file exists for the last {3} days" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $iDaysAgo)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            } else {
                $textOut1 = "{0}  {1} {2} Copying file '{3}'" -f `
                            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile_MostRecent.FullName)
                $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
                $oDest = Get-Item -LiteralPath (Resolve-Path $sServerStorLogsPath).path
                Copy-Item -LiteralPath $oFile_MostRecent.FullName -Destination $oDest
            }
        } catch {
            $err = $_
            $textOut1 = "Failure on {0}" -f @($sClientName)
            $textOut2 = "$textOut1  {0}  Line: {1}: {2}" -f `
                    @($err.Exception.Message
                     ,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim()
                     ,$err.get_InvocationInfo().Line.Trim())
            Write-Host $textOut2
            return # Next in pipeline
        }
    } # End $aComputers | ForEach-Object

    ##### Manipulation of the files from clients that have now been grouped by folder #####
    # Merge UpdatesNeeded into one file
    $oFile = funcMergeAndExportUpdateRequirements (Resolve-Path ($sServerStorResultsPath+'\Needed')).path $sMergedUpdatesNeededFileName
    if ( $oFile ) {
        $textOut1 = "{0}  {1} {2} Updates needed, merged XML file exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile.FullName)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    }

    # Export UpdatesNeeded summary CSV file
    $sTemp = @($sServerStorResultsPath,'\','ComputerUpdateSummary','_',$oMain.GetDateTime_UnderScr(),'.csv') -join ''
    $oMain.CompUpdateResults | Export-Csv -NoTypeInformation -Path $sTemp
    $textOut1 = "{0}  {1} {2} Computer results summary CSV file exported to '{3}'" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sTemp)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    
    # Merge failed downloads into one file
    $oFile = funcMergeAndExportUpdateRequirements (Resolve-Path ($sServerStorResultsPath+'\Failed')).path $sMergedFailedDownloadFileName
    if ( $oFile ) {
        $textOut1 = "{0}  {1} {2} Updates that failed download, merged XML file exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile.FullName)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    }

    # Export cabfile info summary CSV file
    funcImportCabFileInfoXml (Resolve-Path ($sServerStorResultsPath+'\CabFileInfo')).path # Loads info to $oMain.CabFileInfoResults
    $sTemp = @($sServerStorResultsPath,'\','CabFileInfoSummary','_',$oMain.GetDateTime_UnderScr(),'.csv') -join ''
    $oMain.CabFileInfoResults | Export-Csv -NoTypeInformation -Path $sTemp
    $textOut1 = "{0}  {1} {2} Cabfile info summary CSV file exported to '{3}'" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sTemp)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);

    # Create single HTML file from all the workstation (installed updates) XML files.  If formatted correctly, this can be opened in Excel also.
    # There really isn't a reason to create HTML files for the other types of updates as they easily fit in a CSV file for someone to read.
	$textOut1 = "{0}  {1} {2} Working on 'installed updates' HTML file export... " -f `
				@($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
	$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    $aResults = @(Get-ChildItem -LiteralPath (Resolve-Path ($sServerStorResultsPath+'\Installed')).path | `
                Where-Object { -not $_.PSIsContainer } | Where-Object { $_.Extension -eq '.xml' } )
    $aHtmlContent = @()
    $aHtmlContent += '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml"><head><title>HTML TABLE</title>
    <style type="text/css">
    table {
	    border: thin solid lightgray;
	    border-collapse: collapse;
    }
    td {
	    border: thin solid lightgray;
	    padding-left: 10px;
	    padding-right: 10px;
    }
    </style></head><body>'
    $aResults | ForEach-Object {
        $oFile = $_
        $oImportedTemp = Import-Clixml -Path $oFile.FullName
        $oImported = $oImportedTemp | Sort -Property LastDeploymentChangeTime -Descending  # Import+Sorting must be a two step process
        $dtImported = funcConvertTo-DataTable -InputObject $oImported
        $sHtmlTable = ($dtImported | Select * -ExcludeProperty RowError, RowState, HasErrors, Name, Table, ItemArray | ConvertTo-Html -Fragment) -join ''
        $aHtmlContent += $sHtmlTable
    }
    $aHtmlContent += '</body></html>'
    $sHtmlContent = $aHtmlContent -join '</br><hr></br>'
    $sTemp = @((Resolve-Path ($sServerStorResultsPath+'\Installed')).path,'\',$sMergedInstalledUpdatesFileName) -join ''
    Out-File -Force -Confirm:$false -Encoding ascii -InputObject $sHtmlContent -FilePath $sTemp
    $oFile = Get-Item -Path $sTemp
    if ( $aResults.Count -gt 0 ) {
        $textOut1 = "{0}  {1} {2} Merged 'installed updates' HTML file exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile.FullName)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    } else {
        $textOut1 = "{0}  {1} {2} No 'installed updates' XML files were found, a blank HTML file exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oFile.FullName)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    }

    # There isn't anything to do for the log file parsing, just need them gathered to the server
    #$oDest = Get-Item -LiteralPath (Resolve-Path $sServerStorLogsPath).path
} catch {
    $err = $_
    $textOut1 = "{0}  {1} {2}" -f @($oMain.GetDateTime_Iso(), $oMain.ScriptName, 'Script failure!')
    $textOut2 = "$textOut1  {0}  Line: {1}: {2}" -f `
                @($err.Exception.Message
                 ,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim()
                 ,$err.get_InvocationInfo().Line.Trim())
    $oMain.DisplayToScreen($textOut2); $oMain.WriteToLog($textOut2)
}
$textOut1 = "{0}  {1} {2} Script run complete" -f `
            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);



