﻿<#
    .Synopsis
        Copying needed updates to the directory using WSUS API
    .Description
        Download the needed updates from the WSUS server via API and copy
        the files to a destination folder.  The structure under the root folder
        is setup to match Windows update from Microsoft.
        Need to run this on WSUS server with higest privileges (Run as Administrator)                
    .PARAMETER UpdatesNeededFile
        Specify the XML file with the needed updates to retrieve from the WSUS server.
        This paramerter is overridden if the -SkipXmlFile is used.
    .PARAMETER DestinationFolder
        Required: Specify root destination folder for all of the files
    .PARAMETER DownloadOfflineDb
        Optional: Include download/copy of the wsusscn2.cab file from Microsoft
    .PARAMETER SkipXmlFile
        Optional: Skip the required XML file input.  This overrides the UpdatesNeededFile parameter.
    .EXAMPLE
        Copy-WsusUpdateToFolder.ps1 -SkipXmlFile -DownloadOfflineDb
        Download the wsusscn2.cab file, do not request an XML input file,
        prompt the user via GUI for the destination folder.  Copy the cab
        file to the destination.
    .EXAMPLE
        Copy-WsusUpdateToFolder.ps1
        No switches.  Prompt user via GUI for XML input file and via GUI
        for the destination folder. Copy requested updates to destination.
    .EXAMPLE
        Copy-WsusUpdateToFolder.ps1 -l 'c:\path\to\LogFile.txt'
        Prompt user via GUI for XML input file and via GUI for the 
        destination folder. Copy requested updates to destination.
        Log all results to the specified file.
    .EXAMPLE
        Copy-WsusUpdateToFolder.ps1 -UpdatesNeededFile 'C:\UpdatesNeeded-Merged.xml' -DestinationFolder 'G:\web_root'
        No GUI prompts, copy requested updates to destination
    .EXAMPLE
        Copy-WsusUpdateToFolder.ps1 -DownloadOfflineDb -UpdatesNeededFile 'C:\UpdatesNeeded-Merged.xml' -DestinationFolder 'G:\web_root'
        No GUI prompts, copy requested updates+cab DB file to destination
	.NOTES
		Author:  Don Hess
		2019-07-11 Release
#>
param(
    [Parameter(Mandatory=$false,
			   ValueFromPipeline=$true,
               ValueFromPipelineByPropertyName=$true,
               Position=0,
               HelpMessage="Full path to XML import file.  No input will result in a GUI prompt to pick the file")]
    [ValidateNotNullOrEmpty()]
    [string] $UpdatesNeededFile = '--',

    [Parameter(Mandatory=$false,
			   ValueFromPipeline=$true,
               ValueFromPipelineByPropertyName=$true,
               Position=1,
               HelpMessage="Full path to copy destination folder.  No input will result in a GUI prompt to pick the folder")]
    [ValidateNotNullOrEmpty()]
    [string] $DestinationFolder = '--',

    [Parameter(Mandatory=$false,
               Position=2,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage='Include download/copy of the wsusscn2.cab file from Microsoft')] 
    [ValidateSet($true,$false)] 
    [switch] $DownloadOfflineDb = $false,

    [Parameter(Mandatory=$false,
               Position=3,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage='Skip the required XML file input')] 
    [ValidateSet($true,$false)] 
    [switch] $SkipXmlFile = $false,
        
    [Parameter(Mandatory=$false,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               Position=4,
               HelpMessage="Full path to log file.  Enter 'default' to log to the local temp directory")]
    [ValidateNotNullOrEmpty()]
    [string] $l = '--'
)
Set-StrictMode -Version 2 -Verbose
$ErrorActionPreference = 'Stop'
######################### Begin User Variables #####################################
$sScriptName = "Copy-WsusUpdateToFolder.ps1"
$sWsusscn2FileSrc = 'http://download.windowsupdate.com/microsoftupdate/v6/wsusscan/wsusscn2.cab'
#$sWsusscn2FileSrc = 'http://go.microsoft.com/fwlink/?LinkID=74689'  # Web source from MS for wsusscn2.cab file

# Logging options
$bolEnableDisplayToScreen = $true  # Usually turned on all the time
######################### End User Variables #######################################
$oMain = New-Object -TypeName System.Management.Automation.PSObject
Add-Member -InputObject $oMain -MemberType NoteProperty -Name ScriptName -Value $sScriptName
Add-Member -InputObject $oMain -MemberType NoteProperty -Name CompName -Value $env:computername
$sbMethWriteToLog = {
    # Method to write to the log file.
    Param ([string[]] $Msg = '')
    try {
        if ($this.EnableLogging) {
            Out-File -Filepath $this.LogFileFullName -Inputobject $Msg -Append -ErrorAction SilentlyContinue
        }
    } catch {
        $err = $_
        throw $err
    }
}
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name WriteToLog -Value $sbMethWriteToLog
$sbMethDisplayToScreen = {
    # Method to display to screen
    Param ([string[]] $Msg = '')
    if ($this.EnableDisplay) {
        Write-Host $Msg
    }
}
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name DisplayToScreen -Value $sbMethDisplayToScreen
$sbIsoDateLocal = {Get-Date -uformat "%Y-%m-%dT%T%Z"} # ISO 8601 format 2016-08-23T22:10:45+05
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name GetDateTime_Iso -Value $sbIsoDateLocal
$sbDtTodayUnderScr = {Get-Date -uformat "%Y-%m-%d_%I_%M_%S_%p"} # YYYY-MM-DD HH-MM-SS AM/PM  
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name GetDateTime_UnderScr -Value $sbDtTodayUnderScr

try { # Change switch paramater to boolean
    if ( $DownloadOfflineDb.GetType().Name -eq 'SwitchParameter' ) {
    	$t_temp = $DownloadOfflineDb.ToBool()
    	Remove-Variable DownloadOfflineDb
    	$DownloadOfflineDb = $t_temp    # Scoping should be wide enough
        Remove-Variable t_temp
    }else { 
        throw [System.ArgumentException] 'Input must be of type SwitchParameter' 
    }
} catch { $DownloadOfflineDb = $false }
try { # Change switch paramater to boolean
    if ( $SkipXmlFile.GetType().Name -eq 'SwitchParameter' ) {
    	$t_temp = $SkipXmlFile.ToBool()
    	Remove-Variable SkipXmlFile
    	$SkipXmlFile = $t_temp    # Scoping should be wide enough
        Remove-Variable t_temp
    }else { 
        throw [System.ArgumentException] 'Input must be of type SwitchParameter' 
    }
} catch { $SkipXmlFile = $false }

# l  Log file with full path.
# Check for illegal characters / ? < > * | ' " { } ;
$sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
$regex1 = [regex] $sTemp
if ( $l -match $regex1 ) {
    throw [System.ArgumentException] 'Log file input has invlid character(s)' 
}
switch ( $l.ToLower() ) {
    '--' {
        $bolEnableLogging = $false
        $sLogFileFullNameFinal = $l
        break
    }
    'default' {
        # Logging is to be done to the default local temp directory
        $sExt = '.txt'
        $sDtTemp = Invoke-Command -ScriptBlock $sbDtTodayUnderScr
        $sLogFileFullNameFinal = @($env:Temp,"\Log",'_',$sDtTemp,$sExt) -join ''
        $bolEnableLogging = $true
        break
    }
    default {
        # We have some file to log to
        # The Split-Path auto handles the tailing \ on a directory 
        $sDirPath = Split-Path  $l                      # Log file Path only
        $sFileNameWExt = Split-Path -Leaf $l            # Log file Name with extention
        $sExt = '.txt'
        if ( $sFileNameWExt -match "(?<Extension>\.log$|\.txt$)" ) {
            $sFileName = $sFileNameWExt.Remove($sFileNameWExt.length - 4)
            $sExt = $matches.Extension
        } else {
            $sFileName = $sFileNameWExt
        }
        $sDtTemp = Invoke-Command -ScriptBlock $sbDtTodayUnderScr
        $sLogFileFullNameFinal = @($sDirPath,'\',$sFileName,'_',$sDtTemp,$sExt) -join ''
        $bolEnableLogging = $true
        break
    }
}
Add-Member -InputObject $oMain -MemberType NoteProperty -Name LogFileFullName -Value $sLogFileFullNameFinal
Add-Member -InputObject $oMain -MemberType NoteProperty -Name EnableLogging -Value $bolEnableLogging
Add-Member -InputObject $oMain -MemberType NoteProperty -Name EnableDisplay -Value $bolEnableDisplayToScreen

function funcGetFileName( [string] $sInitialDirectory ) {
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    $form = New-Object System.Windows.Forms.OpenFileDialog
    $form.InitialDirectory = $sInitialDirectory
    $form.Filter = "All files (*.*)| *.*"
    $form.ShowDialog() | Out-Null
    try {
        $form.Filename
    }  catch {
        return '--'
    }
} #end function funcGetFileName
function funcGetDateForNthWeekdayOfMonth( [int] $iMonth, [int] $iYear, [int] $iNthOfMonth = 2, [string] $sDayOfWeek = 'Tuesday') {
    # Get the Nth week day of the month: 2nd Tuesday of the month
    # Input: Month and year for the calculation
    # Returns: Datetime object
    $dtFirstDay = Get-Date -Day 1 -Month $iMonth -Year $iYear -Second 0
    $iDaysInThisMonth = ($dtFirstDay).AddMonths(1).AddDays(-1).Day
    for ( $i=0; $i -lt $iDaysInThisMonth; $i++ ) {
        if ( $dtFirstDay.AddDays($i).DayOfWeek -eq $sDayOfWeek ) {
            return ($dtFirstDay.AddDays($i)).AddDays(7*($iNthOfMonth-1))
        }
    }
}
function funcGetOnlyTheseWsusUpdates( [hashtable] $htUpdatesRequired ) {
    <#  .DESCRIPTION
            Get updates from WSUS based the UpdateID
        .PARAMETER htUpdatesRequired
            Hashtable, name is UpdateID guid, value is the update title which is a nice description for the user
        .OUTPUTS
            Array with individual update object or empty array
    #>
    $aReturned = @()
    $htUpdatesRequired.GetEnumerator() | ForEach-Object {
        $sUpdateId = $_.Name
        $sUpdateTitle = $_.Value
        $oSingleUpdate = $null
        try {
            # GetUpdate() takes only the update ID
            $oSingleUpdate = $oWsusServer.GetUpdate([guid]$sUpdateId)
            # SearchUpdates take everything EXCEPT update ID
            #$oWsusServer.SearchUpdates($somethinghere)
            $aReturned += $oSingleUpdate
        } catch {
            $err = $_
            $textOut1 = "{0}  {1} {2} Error: {3}, Line: {4}, {5}" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName,$err.Exception.Message,
                  $err.get_InvocationInfo().ScriptLineNumber.ToString().Trim(),$err.get_InvocationInfo().Line.Trim())
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
        }
    }
    return ,$aReturned
}
function funcGetUpdateFileListing( [array] $aUpdates ) {
    <#  .DESCRIPTION
            Get the individual files for the input updates
        .PARAMETER aUpdates
            Array of WSUS updates
        .OUTPUTS
            Array with individual files from each update, or an empty array
    #>
    $aFiles = @()
    $aUpdates | ForEach-Object {
        $oSingleUpdate = $_
        $aFiles += @( $oSingleUpdate.GetInstallableItems().Files | `
            Where-Object {($_.Type -eq 'SelfContained') -or 
                (($_.Type -eq 'None') -and ($_.IsEula -eq $False))  # Filter out Eula files from EXEs
            } | Select Name,FileUri,OriginUri,Type,Hash,AdditionalHash
        )
    }
    return ,$aFiles
}
function funcDownloadFileViaHttp( [string] $sFullNameDownload, [string] $sDestinationPath, [string] $sFileName='', [int] $iProgressDelay=1 ) { 
    <#  .DESCRIPTION 
            Download a file via HTTP(s).  PS v2 compatible. 
            This process will OVERWRITE a file with the same name in the destination 
            Large file sizes and long download times are supported 
        .PARAMETER sFullNameDownload 
            Full name download location 
        .PARAMETER sDestinationPath 
            Destination path for the file after download 
        .PARAMETER sFileName 
            Override the automatically calculated file name in sFullNameDownload with this specified name. 
        .PARAMETER iProgressDelay 
            How many seconds to wait to update the progress meter 
        .RETURNS 
            The destination file object 
    #> 
    # Set this session connection to TLS 1.2
    #[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    #[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls
    $oHttpWebRequest = [System.Net.HttpWebRequest]::Create($sFullNameDownload) 
    $oHttpWebRequest.KeepAlive = $true 
    $oHttpWebResponse = $oHttpWebRequest.GetResponse() 
    if ( $oHttpWebResponse.StatusCode.value__ -eq 200) { 
        if ($sFileName -eq '') { 
            $sFileName = $oHttpWebRequest.RequestUri.Segments[-1] 
        } 
        $sDestinationPath = (Resolve-Path $sDestinationPath).Path 
        $sFileFullNameFinal = Join-Path $sDestinationPath $sFileName 
        $oStream = $oHttpWebResponse.GetResponseStream() 
        $iContentLength = $oHttpWebResponse.ContentLength  # Progress 
        $iByteCountStatus = 0  # Progress 
        [byte[]] $buffer1 = New-Object byte[] 4096 
        $oStreamDest = New-Object System.IO.FileStream ($sFileFullNameFinal,[IO.FileMode]::Create) 
        $dblFutureTime = [double] (Get-Date -UFormat %s) 
        $iProgTestDelay = $iProgTestDelayLast = 1000 * $iProgressDelay  # Number of loops before we even check the datetime 
        do { 
            # This process will OVERWRITE a file with the same name in the destination 
            $iByteCountFilled = $oStream.Read($buffer1,0,($buffer1.Length)) 
            $oStreamDest.Write($buffer1,0,$iByteCountFilled) 
            $iByteCountStatus += $iByteCountFilled  # Progress 
            # Add a delay in displaying the progress.  This allows faster downloads 
            if ( $iProgTestDelay -le 0 ) { 
                $dblTimeNow = [double] (Get-Date -UFormat %s) 
                $bolProgDelayOvershoot = $false 
                if ( $dblTimeNow -ge $dblFutureTime ) { 
                    # Timer has elapsed, update progress bar 
                    if ( $dblTimeNow -ge ($dblFutureTime+$iProgressDelay) ) { 
                        # We have overshot our display time. This happens on slow links.  
                        # Need to decrease the loop counter so progress stays on time 
                        $bolProgDelayOvershoot = $true 
                    } 
                    $sProgressStatus = @("[",$iByteCountStatus,"/",$iContentLength,"] bytes completed") -join ""  # Progress 
                    Write-Progress -Activity "Downloading" -Status $sProgressStatus  -PercentComplete ([int]($iByteCountStatus/$iContentLength * 100))  # Progress 
                    $dblFutureTime = ([double] (Get-Date -UFormat %s)) + $iProgressDelay 
                } 
                if ( $bolProgDelayOvershoot ) { 
                    # This will decrease the number of loops that occur prior to datetime check 
                    # Eventually the loop delay will adjust into the iProgressDelay value 
                    $iProgTestDelay = $iProgTestDelayLast = [int] ($iProgTestDelayLast/3) 
                } else { 
                    $iProgTestDelay = $iProgTestDelayLast 
                } 
            } 
            $iProgTestDelay-- 
        } while ($iByteCountFilled -ne 0) 
        $oStreamDest.Close() 
        $oStream.Close() 
        $oStream.Dispose() 
        $oFile = Get-Item $sFileFullNameFinal 
    } else { 
        throw 'Bad response from web server' 
    } 
    return ,$oFile 
} # End of function funcDownloadFileViaHttp 
function funcGetFileInfoViaHttp( [string] $sFullName ) {
    $oHttpWebRequest = [System.Net.HttpWebRequest]::Create($sFullName)
    $oHttpWebRequest.KeepAlive = $false
    $oHttpWebRequest.Method = 'HEAD'
    $oHttpWebResponse = $oHttpWebRequest.GetResponse()
    $oHttpWebResponse
}
function funcCreateFolderPath( [string] $sPathIn ) {
    <#  .DESCRIPTION
             Create an entire Windows folder path one folder at a time
        .PARAMETER sPathIn
             String containing the full path to the folder.  
             Accepts local or remote servers.  
                C:\  C:\myfolder1   \\server\share  \\server\share\myfolder1
                '~'  '~\new1\new2'  (empty str)   '.'  '.\'  '.\new1\new2'
        .OUTPUTS
            Directory object of the last folder created
    #>
    if ( $sPathIn -eq '' ) {  # Empty string, get current path
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    if ( $sPathIn -eq '.' ) { # Current path only
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    # Check for illegal characters  / ? < > * | ' " { } ;   Allows  c:\  \\server
    $sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( ($sPathIn -match $regex1) -or ([string]::IsNullOrWhiteSpace($sPathIn)) ) {
        $textOut1 = "Folder path '{0}' has illegal character(s)" -f @($sPathIn)
        throw [System.ArgumentException] $textOut1
    }
    if ( Test-Path -PathType Container -Path $sPathIn ) {
        $oTempPath = Get-Item -Path $sPathIn
        return ,$oTempPath
    }
    $oTempPath = New-Item -Path $sPathIn -Type Directory
    return ,$oTempPath
} # End funcCreateFolderPath
function funcValidateFilenameStringInput( [string] $sIn ) {
    # Check for illegal characters / ? < > * | ' " { } [] = ;
    $sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\[','\]','\=','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( $sIn -match $regex1 ) {
        $sError = "Input '{0}' has invlid character(s)" -f @($sIn)
        throw [System.ArgumentException] $sError  
    }
}
function funcExtractFilesFromCab( [System.IO.FileInfo] $oCabFile, 
                                  [array] $aFileNames, 
                                  [System.IO.DirectoryInfo] $oDestDir ) {
    <#  .DESCRIPTION
            Extract file(s) from a CAB file.  Tested on Win 7 and 2012R2
        .PARAMETER oCabFile
            File object, Source CAB file.  Must be pre-existing
        .PARAMETER aFileNames
            Array, Short file name(s) to be extracted from the cab file
        .PARAMETER oDestDir
            Directory object, Destination directory.  Must be pre-existing.
        .OUTPUTS
            Nothing
        .NOTES
            Requires funcValidateFilenameStringInput function be available
    #>
    funcValidateFilenameStringInput $oCabFile.FullName
    $aFileNames | ForEach-Object {
        $sFileName = [string] $_
        # FIX ME:  Need same validation input as the log file
        funcValidateFilenameStringInput $sFileName
        if ( Test-Path -PathType Leaf (Join-Path $oDestDir $sFileName) ) {
            Get-Item (Join-Path $oDestDir $sFileName) | Remove-Item -Force
        }
    }
    funcValidateFilenameStringInput $oDestDir.FullName
    if ( -not (Test-Path -PathType Leaf $oCabFile) ) {
        throw 'oCabFile needs to be an existing cab file object'
    }
    if ( -not (Test-Path -PathType Container $oDestDir) ) {
        throw 'oDestDir needs to be an existing directory object'
    }
    # expand.exe source.cab -F:Filename Destination
    $aFileNames | ForEach-Object {
        $sFileName = [string] $_
        $sExeTemp = @("expand.exe"," ",$oCabFile.FullName," ","-F:'",$sFileName,"' ",$oDestDir.FullName) -join ''
        $oResult = Invoke-Expression $sExeTemp
    }
}

################################ MAIN ################################
######################################################################
$textOut1 = "{0}  {1} {2} Test write to log" -f `
    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
$htUpdatesRequired = @{}
if ( $SkipXmlFile ) {
    Out-Null
} else {
    if ( $UpdatesNeededFile -eq '--') {
        # Need to promt user to pick something via the GUI
        $UpdatesNeededFile = funcGetFileName
    }
    # Something should be passed in/set by now
    $htUpdatesRequired = Import-Clixml -Path $UpdatesNeededFile
}
if ( $DestinationFolder -eq '--' ) {
    # Need to promt user to pick something via the GUI
    $app = New-Object -ComObject Shell.Application
    #$DestinationFolder = ($app.BrowseForFolder(0, "Select Updates Destination Folder", 0, "C:\")).Self.Path
    $DestinationFolder = ($app.BrowseForFolder(0, "Select Updates Destination Folder", 0, "")).Self.Path
    $oDestFolder = Get-Item -Path $DestinationFolder
} else {
    # Some type of path passed in
    $oDestFolder = Get-Item -Path $DestinationFolder
}
if ( -not $oDestFolder.PSIsContainer ) {
    throw [System.ArgumentException] 'DestinationFolder input must be a folder'
}
if ( $DownloadOfflineDb ) {
    # Validate that the wsusscn2.cab file has been updated recently by MS
    $iDaysAgo = 5  # File must be newer than this many days
    $oTempResponse = funcGetFileInfoViaHttp $sWsusscn2FileSrc
    $textOut1 = '{0}  {1} {2} Offline database file modify date on server is {3}' -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oTempResponse.LastModified.ToString())
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    $dtNow = Get-Date
    $dtSecondTuesday = funcGetDateForNthWeekdayOfMonth $dtNow.Month $dtNow.Year
    if ( ($oTempResponse.LastModified -lt $dtSecondTuesday.AddDays(0-$iDaysAgo)) `
     -or ($oTempResponse.LastModified -gt $dtSecondTuesday.AddDays($iDaysAgo)) ) {  # Must be in date window to be valid
        $sError = "File {0} is ouside of +/- {1} day window.  Has MS delayed releasing a new file?" -f @($sWsusscn2FileSrc,$iDaysAgo)
        throw $sError
    }
    # Download the wsusscn2.cab file to a local temporary location
    $textOut1 = "{0}  {1} {2} Download started for wsusscn2.cab file.  This might take some time..." -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    $sWsusscn2FileTempDest = $env:Temp
    $oWsusscn2File = funcDownloadFileViaHttp $sWsusscn2FileSrc $sWsusscn2FileTempDest 'wsusscn2.cab'
    $textOut1 = "{0}  {1} {2} Download completed for wsusscn2.cab file." -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    # Validate that the wsusscn2.cab file has been updated recently by MS
    $sTestFile = 'index.xml'  # Filename inside cab to check the date
    $aFileNamesOut = @($sTestFile)
    funcExtractFilesFromCab -oCabFile $oWsusscn2File -aFileNames $aFileNamesOut -oDestDir (Get-Item $sWsusscn2FileTempDest)
    $oTestFile = Get-Item (Join-Path $sWsusscn2FileTempDest $sTestFile)
    $textOut1 = '{0}  {1} {2}  Offline database file modify date after download is {3}' -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oTestFile.LastWriteTime)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    #if ( $oTestFile.LastWriteTime -lt (Get-Date).AddDays(0-$iDaysAgo) ) {
    #    $sError = "Downloaded file is older than {0} days ago.  Has MS delayed releasing a new file?" -f @($iDaysAgo)
    #    throw $sError
    #}
    # Copy wsusscn2.cab file to final destination, force overwrite
    # Just going to list the MS web server path here to keep it simple
    $aSegments = @($oDestFolder.FullName,'microsoftupdate','v6','wsusscan')
    $sFilePathDest = $aSegments -join '\'
    funcCreateFolderPath $sFilePathDest | Out-Null
    Copy-Item -Force -Confirm:$false $oWsusscn2File -Destination $sFilePathDest
    $textOut1 = "{0}  {1} {2} Copy to '{3}' succeeded" -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sFilePathDest)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
}
if ( $htUpdatesRequired.count -eq 0 ) {
    $textOut1 = "{0}  {1} {2} No updates listed in XML file provided by you.  Nothing more to do.  Script run complete." -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    return
} else {
    $textOut1 = "{0}  {1} {2} Imported XML file is: '{3}'" -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName,$UpdatesNeededFile)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
}
$textOut1 = "{0}  {1} {2} Destination copy folder is: '{3}'" -f `
    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName,$oDestFolder.FullName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
if ( $SkipXmlFile ) {
    # Rest of script require WSUS input so we need to stop here
    $textOut1 = "{0}  {1} {2} Script run complete" -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    return
}

#-------------------------------------------------------------
$oWsusServer = Get-WsusServer
#[void][Reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration")
#$oWsusServer = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer()
$sWsusCacheFilePath = $oWsusServer.GetConfiguration().LocalContentCachePath
$aUpdates = funcGetOnlyTheseWsusUpdates $htUpdatesRequired
# Approve any EULAs that are needed and approve these updates for installation on the computer group
$oAllComputersGroup = $oWsusServer.GetComputerTargetGroups() | Where-Object { $_.Name -eq 'All Computers'}
$aUpdates | Where-Object { $_.RequiresLicenseAgreementAcceptance } | ForEach-Object { $_.AcceptLicenseAgreement() }
$aUpdates | Where-Object { -not $_.IsApproved } | ForEach-Object { $_.ApproveForOptionalInstall($oAllComputersGroup) } | Out-Null

$textOut1 = "{0}  {1} {2} Waiting for newly approved WSUS updates to finish downloading.  This might take some time..." -f `
    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
$bolDownloading = $true
while ( $bolDownloading ) {
    $iBytesDown = $oWsusServer.GetContentDownloadProgress().DownloadedBytes
    $iBytesTotal = $oWsusServer.GetContentDownloadProgress().TotalBytesToDownload
    $sProgressStatus = @("[",$iBytesDown,"/",$iBytesTotal,"] bytes completed") -join ""
    $iProgressPercComp = [int] ($iBytesDown/$iBytesTotal * 100)
    Write-Progress -Activity "Downloading" -Status $sProgressStatus -PercentComplete $iProgressPercComp
    if ( $iBytesDown -eq $iBytesTotal ) {
        $bolDownloading = $false
    } else {
        sleep 2
    }
}
$textOut1 = "{0}  {1} {2} Downloads complete. Copying local files to destination." -f `
    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
$aWsusFiles = funcGetUpdateFileListing $aUpdates
$aWsusFiles | ForEach-Object {
    $oSingleUpdate = $_
    # Get the local file name and location for the source
    $sFileNameSrc = $oSingleUpdate.FileUri.Segments[-1]
    $sFilePartialPathSrc = $oSingleUpdate.FileUri.LocalPath -replace "\/content\/" -replace "\/","\"  # Last half of path+filename
    $sFileFullNameSrc = @($sWsusCacheFilePath,$sFilePartialPathSrc) -join '\'
    # Get the origin web download from MS, parse, and set up the folder structure that is after the domain.
    # This allows us to just copy the entire file system structure to the offline web server environment.
    # http://download.windowsupdate.com/c/msdownload/update/software/secu/2016/12/windows6.1-kb3205394-x64_a98523a51d6fc243082224db0a0f10a312bcddc2.psf
    $oParsedUrl = [System.Uri] $oSingleUpdate.OriginUri
    # Need to make sure the segments of the URL array cells and are a true PS array object, not a string.
    # Skip the filename in the last cell.  Strip off foward slashes.
    $aSegments = @($oDestFolder.FullName)
    $aSegments += $oParsedUrl.Segments[0..($oParsedUrl.Segments.Length-2)] | ForEach-Object {
        $sTemp = $_.Replace('/','')
        if ( $sTemp.length -gt 0 ) { # Filter out '/' only cell at begining
            $sTemp
        }
    }
    $sFileNameDest = $oParsedUrl.Segments[-1]
    $sFilePathDest = $aSegments -join '\'
    $sFileFullNameDest = @($sFilePathDest.TrimEnd('\'),$sFileNameDest) -join '\'  # A double slash is handled OK by Copy-Item D:\\somefile.cab
    funcCreateFolderPath $sFilePathDest | Out-Null
    try {
        if ( Test-Path -PathType Leaf -Path $sFileFullNameDest ) {
            $textOut1 = "{0}  {1} {2} Found existing destination file '{3}'." -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sFileFullNameDest)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            return  # File already exists, return out of pipeline object
        }
        $textOut1 = "{0}  {1} {2} Copying '{3}' to '{4}'." -f `
            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sFileFullNameSrc, $sFilePathDest)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
        $textOut1 = "{0}  {1} {2} Original URL is '{3}'." -f `
            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oSingleUpdate.OriginUri)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
        Copy-Item -Path $sFileFullNameSrc -Destination $sFilePathDest  # This has the WSUS filename, not the MS web filename
        $oFileDestTemp = Get-Item -Path (@($sFilePathDest,$sFileNameSrc) -join '\')
        Rename-Item $oFileDestTemp -NewName $sFileNameDest
    } catch {
        $err = $_
        $textOut1 = "{0}  {1} {2} Error: {3}, Line: {4}, {5}" -f `
            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName,$err.Exception.Message,
                $err.get_InvocationInfo().ScriptLineNumber.ToString().Trim(),$err.get_InvocationInfo().Line.Trim())
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    }
} # End ForEach-Object

$textOut1 = "{0}  {1} {2} Copy of files to destination complete." -f `
    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
$textOut1 = "{0}  {1} {2} Script run complete" -f `
    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);


