# Install all the components for the Manage-WindowsUpdate-Client.ps1 script
param ([switch] $Install, [switch] $Uninstall)

Set-StrictMode -Version latest -Verbose
$ErrorActionPreference = 'Stop'
$PSDefaultParameterValues['*:ErrorAction']='Stop'

# Source folder path
$sSrcRoot = 'http://wsusfileshare.mydomain.com/scripts'  # No trailing slash
# Comment out the lines you do not want to deploy to clients
$aFilesToCopy = @(
     'Manage-WindowsUpdate-Client.ps1'
    ,'Task-WinUpdate-ApplyUpdates-Offline.xml'
    ,'Task-WinUpdate-ApplyUpdates-Offline_wReboot.xml'
    ,'Task-WinUpdate-ApplyUpdates-Online.xml'
    ,'Task-WinUpdate-CheckForUpdates-Offline.xml'
    ,'Task-WinUpdate-CheckForUpdates-Online.xml'
    ,'Task-WinUpdate-DownloadOfflineDb.xml'
    ,'Task-WinUpdate-InstalledUpdates.xml'
)
# Destination install root
$sInstallRoot = 'C:\ProgramFiles2\WinUpdateScripts'
# Needed subfolders, Admin can write to these so default perms will work
$aSubfolders = @(
    # Can also enter nested folders in a cell: 'Fld1\sub1\sub2'
     'Logs'
    ,'Results'
)
# Users that have full access to the install root
$aInstallRootUserAccess = @('Builtin\Administrators','NT AUTHORITY\SYSTEM')

function funcSetPermsOnFolder($oFolder, [array] $aUsers) {
    # Set permissions on folder so users have full control
    # Disable inheritance, remove all existing permissions, add only what we need
    $oFolderAcl = $oFolder.GetAccessControl()
    # Disable inheritance. I'd rather preserve existing rules and remove them manually later
    $oFolderAcl.SetAccessRuleProtection($true,$true) # (Protect this obj from inheritance, preserve existing rules)
    $oFolder.SetAccessControl($oFolderAcl)
    $oFolderAcl = $oFolder.GetAccessControl()
    # Manually remove access rules
    $oFolderAcl.Access | ForEach-Object {
        $oFolderAcl.RemoveAccessRule($_) | Out-Null
    }
    # Set inheritance to "This folder, subfolders, and files" for directories
    $oInheritFlags = [System.Security.AccessControl.InheritanceFlags]"ContainerInherit,ObjectInherit"
    $oProgFlags = [System.Security.AccessControl.PropagationFlags]"None"
    $oFileSysRights = [System.Security.AccessControl.FileSystemRights]"FullControl"
    $aUsers | ForEach-Object {
        $oAr = New-Object System.Security.AccessControl.FileSystemAccessRule($_, $oFileSysRights, $oInheritFlags, $oProgFlags, "Allow")
        $oFolderAcl.AddAccessRule($oAr)
    }
    $oFolder.SetAccessControl($oFolderAcl)
}
function funcDownloadFileViaHttp( [string] $sFullNameDownload, [string] $sDestinationPath, [string] $sFileName = '' ) {
    <#  .DESCRIPTION
            Download a file via HTTP(s).  PS v2 compatible.
            This process will OVERWRITE a file with the same name in the destination
            Large file sizes and long download times are supported
        .PARAMETER sFullNameDownload
            Full name download location
        .PARAMETER sDestinationPath
            Destination path for the file after download
        .PARAMETER sFileName
            Override the automatically calculated file name in sFullNameDownload with this specified name.
        .OUTPUTS
            The destination file object
    #>
    $oHttpWebRequest = [System.Net.HttpWebRequest]::Create($sFullNameDownload)
    $oHttpWebRequest.KeepAlive = $true
    $oHttpWebResponse = $oHttpWebRequest.GetResponse()
    if ( $oHttpWebResponse.StatusCode.value__ -eq 200) {
        if ($sFileName -eq '') {
            $sFileName = $oHttpWebRequest.RequestUri.Segments[-1]
        } 
        $sFileFullNameFinal = @($sDestinationPath,'\',$sFileName) -join ''
        $oStream = $oHttpWebResponse.GetResponseStream()
        [byte[]] $buffer1 = New-Object byte[] 4096
        $oStreamDest = New-Object System.IO.FileStream ($sFileFullNameFinal,[IO.FileMode]::Create)
        do {
            # This process will OVERWRITE a file with the same name in the destination
            $iByteCountFilled = $oStream.Read($buffer1,0,($buffer1.Length))
            $oStreamDest.Write($buffer1,0,$iByteCountFilled)
        } while ($iByteCountFilled -ne 0)
        $oStreamDest.Close()
        $oStream.Close()
        $oStream.Dispose()
        $oFile = Get-Item $sFileFullNameFinal
    } else {
            throw 'Bad response from web server'
    }
    return ,$oFile
} # End of function funcDownloadFileViaHttp
function funcStringIsNullOrWhitespace([string] $string) {
    if ($null -ne $string) { $string = $string.Trim() }
    return [string]::IsNullOrEmpty($string)
}
function funcCreateFolderPath( [string] $sPathIn ) {
    <#  .DESCRIPTION
             Create an entire Windows folder path one folder at a time
        .PARAMETER sPathIn
             String containing the full path to the folder.  
             Accepts local or remote servers.  
                C:\  C:\myfolder1   \\server\share  \\server\share\myfolder1
                '~'  '~\new1\new2'  (empty str)   '.'  '.\'  '.\new1\new2'
        .OUTPUTS
            Directory object of the last folder created
    #>
    if ( $sPathIn -eq '' ) {  # Empty string, get current path
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    if ( $sPathIn -eq '.' ) { # Current path only
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    # Check for illegal characters  / ? < > * | ' " { } ;   Allows  c:\  \\server
    $sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( ($sPathIn -match $regex1) -or (funcStringIsNullOrWhitespace $sPathIn ) ) {
        $textOut1 = "Folder path '{0}' has illegal character(s)" -f @($sPathIn)
        throw [System.ArgumentException] $textOut1
    }
    if ( Test-Path -PathType Container -Path $sPathIn ) {
        $oTempPath = Get-Item -Path $sPathIn
        return ,$oTempPath
    }
    $oTempPath = New-Item -Path $sPathIn -Type Directory
    return ,$oTempPath
} # End funcCreateFolderPath


################################ MAIN ################################
######################################################################
Write-Host "Computer:" $env:COMPUTERNAME

if ( $Uninstall.IsPresent ) {
    if ( Test-Path -Path $sInstallRoot ) {
        # Work around bug in Remove-Item
        Get-ChildItem -Path $sInstallRoot | Remove-Item -Recurse -Force -Confirm:$false 
        Remove-Item -Recurse -Force -Confirm:$false -Path $sInstallRoot
        Write-Host "Root folder '$sInstallRoot' deleted" 
    } else {
        Write-Host "Root folder '$sInstallRoot' does not exist"
    }
    $aFilesToCopy | ForEach-Object {
        if ($_ -match '^Task-') {
            # Strip off extra stuff to get just the task name
            $sTaskName = $_.Replace('Task-','').Replace('.xml','')
            # Win 7 needs to use command line
            try {
                & schtasks /delete /f /tn "$sTaskName"
                # Write-Host 'Task deleted:' $sTaskName
            } catch {
                Write-Host 'Could not find task' $sTaskName
                
            }
        }
    }
    Write-Host 'Uninstall complete'
}

if ( $Install.IsPresent ) {
    Write-Host 'Creating destination folder structure'
    funcSetPermsOnFolder -oFolder (funcCreateFolderPath $sInstallRoot) -aUsers $aInstallRootUserAccess
    $aSubfolders | ForEach-Object {
        $sTemp = @($sInstallRoot,$_) -join '\'
        funcCreateFolderPath $sTemp | Out-Null
    }
    Write-Host 'Copying files'
    $aFilesToCopy | ForEach-Object {
        $sTemp = @($sSrcRoot,$_) -join '/'
        Write-Host 'Getting' $sTemp
        funcDownloadFileViaHttp $sTemp $sInstallRoot | Out-Null  # No need to indicate dest file name explicitly
    }
    Write-Host 'Importing scheduled tasks'
    $aFilesToCopy | ForEach-Object {
        if ($_ -match '^Task-') {
            # File is a task.  Strip off extra stuff to get just the task name
            $sTaskName = $_.Replace('Task-','').Replace('.xml','')
            $sXmlFileFullName = @($sInstallRoot,'\',$_) -join ''
            # Win 7 needs to use command line
            try {
                & schtasks /create /tn "$sTaskName" /xml "$sXmlFileFullName"
                #Write-Host 'Task imported:' $sTaskName
            } catch {
                Write-Host 'Error occured creating task from file' $sXmlFileFullName
            }
        }
    }
}
Write-Host 'Script run complete'