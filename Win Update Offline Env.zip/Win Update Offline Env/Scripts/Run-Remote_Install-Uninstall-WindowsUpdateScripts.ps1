﻿# Run a PS script file over a remote connection.
# Pass named parameters by creating a masive script block with 
# the parameters as a formated string at the end.

param ([switch] $Install, [switch] $Uninstall, [array] $Computers = @())

Set-StrictMode -Version latest -Verbose
$ErrorActionPreference = 'Stop'
$PSDefaultParameterValues['*:ErrorAction']='Stop'

if ( -not $Computers ) {
    # Get a listing of all workstations
    #$sDomainSnip = (Get-WmiObject Win32_ComputerSystem).Domain.Trim().Substring(0,3)
    $aComputers = Get-ADComputer -Filter * | Select-Object Name,DNSHostName,Enabled | `
        Where-Object { $_.Enabled -and $_.Name -Like "WKNAMES*" -and $null -ne $_.DNSHostName } | `
        ForEach-Object { $_.Name } | Sort
} else {
    # Something passed in
    $aComputers = $Computers
}

# Params for remote computer
$aParams = @()
if ( $Install.IsPresent ) {
    $aParams += '-Install'
}
if ( $Uninstall.IsPresent ) {
    $aParams += '-Uninstall'
}
if ( $Computers.count -ne 0 ) {
    # Something passed in
    $aComputers = $Computers
}
$sScriptPath = '\\myservername\S1\wsusfileshare\scripts\Install-Uninstall-WindowsUpdateScripts.ps1'
$sScriptContent = Get-Content $sScriptPath -Raw
$aFormattedParams = &{ $args } @aParams
# The `.{}` statement could be replaced with `&{}` here, because we don't need to persist variables after script call.
$sScriptBlockContent = "&{ $sScriptContent } $aFormattedParams"
$sbFinal = [scriptblock]::create($sScriptBlockContent)

# All of the Invoke-Command work
Invoke-Command -ThrottleLimit 3 -ComputerName $aComputers -ScriptBlock $sbFinal -ErrorAction Continue

# $Cred = Get-Credential
#Invoke-Command -ComputerName '' -Credential $Cred -ScriptBlock $sbFinal

#$session = New-PSSession -ComputerName '' -Credential $Cred
#Invoke-Command -Session $session -ScriptBlock $sbFinal
#Remove-PSSession $session

