<# 
.SYNOPSIS
    Manage workstation updates via Windows Update API
.DESCRIPTION  
    Manage workstation updates via Windows Update API
.PARAMETER UseOfflineDb
    Use the wsusscn2.cab database file as the source for updates.  The wsusscn2.cab file contains
    information only about security updates, update rollups and service packs.
    If not specified, the script will check online with Microsoft. 
.PARAMETER DownloadOfflineDb
    Download/copy of the wsusscn2.cab file from the internal server.
.PARAMETER ApplyUpdates
    Apply/Install updates from the Windows repository (online or offline)
.PARAMETER CheckForUpdates
    Check for new updates, export needed updates to an XML file at the specified path. 
    Specify 'stdout' for output to stdout, 'default' to the root locations specifed in 
    the user variable section of this script
.PARAMETER InstalledUpdates
    Get the installed updates, export to an XML file at the specified path.
    Specify 'stdout' for output to stdout, 'default' to the root locations specifed in 
    the user variable section of this script
.PARAMETER Reboot
    Number of seconds to wait, then force reboot the machine after updates have completed.  
    Value of -1 is default, means to let Windows update take care of reboot.
.PARAMETER l
    Log to file.  Enter 'default' to log to the local temp directory
.OUTPUT
    XML file of needed updates to location specified via -CheckForUpdates
    XML file of failed downloads to the root locations specifed in the user variable section of this script
    Log file to the location specified via -l
.EXAMPLE
    Manage-WindowsUpdate-Client.ps1 -DownloadOfflineDb
    Download the offline database to the local client.  Overrites the existing offline database.
.EXAMPLE
    Manage-WindowsUpdate-Client.ps1 -DownloadOfflineDb -l 'default'
    Download the offline database to the local client.  Log to the default loggin folder defined in this 
    scripts User Varible section.
.EXAMPLE
    Manage-WindowsUpdate-Client.ps1 -UseOfflineDb -CheckForUpdates 'default' -l 'default'
    Use the local copy of the offline database if it already exists to check for needed updates.
    Output results to the default ResultsRoot folder specified in the User Variables section of this script.
    Log to the default LogRoot folder specified in the User Variables section of this script
.EXAMPLE 
    Manage-WindowsUpdate-Client.ps1 -UseOfflineDb -CheckForUpdates '\\server\share\Compname-UpdatesNeeded.xml'
    Use the local copy of the offline database if it already exists to check for needed updates.
    Export the results to a XML file
.EXAMPLE 
    Manage-WindowsUpdate-Client.ps1 -UseOfflineDb -CheckForUpdates .\Compname-UpdatesNeeded.xml -l mylogfile.txt
    Use the local copy of the offline database if it already exists to check for needed updates.
    Export the results to a XML file in the current working path.  Must have the .\ or the path
    to the file cannot be checked and will thow and error.  The log file can be just a name to
    output the the current working path.
.EXAMPLE 
    Manage-WindowsUpdate-Client.ps1 -UseOfflineDb -CheckForUpdates 'stdout' -l mylogfile.txt
    Use the local copy of the offline database if it already exists to check for needed updates.
    Output results as an object to the pipeline.  Log to file in current working directory.
.EXAMPLE 
    Manage-WindowsUpdate-Client.ps1 -UseOfflineDb -CheckForUpdates 'default' -l mylogfile.txt
    Use the local copy of the offline database if it already exists to check for needed updates.
    Output results to the default ResultsRoot folder specified in the User Variables section of this script.
    Log to file in current working directory.
.EXAMPLE 
    Manage-WindowsUpdate-Client.ps1 -CheckForUpdates '\\server\share\Compname-UpdatesNeeded.xml'
    Check online for needed updates.  (Go to Microsoft)  Export the results to an XML file
.EXAMPLE 
    Manage-WindowsUpdate-Client.ps1 -UseOfflineDb -DownloadOfflineDb -ApplyUpdates -l '\\server\share\mylogfile.txt'
    Download the offline database to the local client.   Use the local copy of the offline database
    to determine what updates need installation.  Client will download updates from within the
    offline environment.  Log everything to a server text file.
.NOTES
    To have the script work in 'offline' mode, you need to redirect download.microsoft.com DNS to an internal web server 
    that hosts the updates in a structure that matches what Microsoft would use.
    
    See interfaces not available to remote users:  https://msdn.microsoft.com/en-us/library/windows/desktop/aa387288(v=vs.85).aspx
    
    Author: Don Hess
    Version History:
    1.0    2019-07-11   Release for PS v2+
.LINK
    NA
#> 
[CmdletBinding()]
param (
    [Parameter(Mandatory=$false,
               Position=1,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage='Use the wsusscn2.cab database')] 
    [ValidateSet($true,$false)] 
    [switch] $UseOfflineDb = $false,

    [Parameter(Mandatory=$false,
               Position=2,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage='Download/copy of the wsusscn2.cab file from the internal server.')] 
    [ValidateSet($true,$false)] 
    [switch] $DownloadOfflineDb = $false,

    [Parameter(Mandatory=$false,
               Position=3,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage='Apply/Install updates from the internally available Windows repository')] 
    [ValidateSet($true,$false)] 
    [switch] $ApplyUpdates = $false,

    [Parameter(Mandatory=$false,
               Position=4,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage="Check for new updates, output to file")] 
    [ValidateNotNullOrEmpty()] 
    [string] $CheckForUpdates = '--',

    [Parameter(Mandatory=$false,
               Position=5,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               HelpMessage="Get installed updates, output to file")] 
    [ValidateNotNullOrEmpty()] 
    [string] $InstalledUpdates = '--',

    [Parameter(Mandatory=$false,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               Position=6,
               HelpMessage='Number of seconds to wait, then reboot')]
    #[ValidateSet($true,$false)]
    [ValidateRange(-1,3600)]
    [int] $Reboot = -1,
    
    [Parameter(Mandatory=$false,
               ValueFromPipeline=$false,
               ValueFromPipelineByPropertyName=$false,
               Position=7,
               HelpMessage="Log to file.  Enter 'default' to log to the local temp directory")]
    [ValidateNotNullOrEmpty()]
    [string] $l = '--'
)

Set-StrictMode -Version latest -Verbose
$ErrorActionPreference = 'Stop'
######################### Begin User Variables #####################################
$sScriptName = "Manage-WindowsUpdate-Client.ps1"
$sWsusscn2FileSrc = 'http://download.windowsupdate.com/microsoftupdate/v6/wsusscan/wsusscn2.cab'  # This will cover internal and external download.  Must include .cab file name
$sWsusscn2FileDest = 'C:\Windows\SoftwareDistribution\wsusscn2_offline\wsusscn2.cab'  # Local destination.  Must include .cab file name
$sResultsRoot = 'C:\ProgramFiles2\WinUpdateScripts\Results'  # The default location for XML output
$sLogRoot = 'C:\ProgramFiles2\WinUpdateScripts\Logs'  # The default location for log output

# Logging options
$bolEnableDisplayToScreen = $true  # Usually turned on all the time
######################### End User Variables #######################################

$oMain = New-Object -TypeName System.Management.Automation.PSObject
Add-Member -InputObject $oMain -MemberType NoteProperty -Name ScriptName -Value $sScriptName
Add-Member -InputObject $oMain -MemberType NoteProperty -Name CompName -Value $env:computername

$sbMethWriteToLog = {
    # Method to write to the log file.
    Param ([string[]] $Msg = '')
    try {
        if ($this.EnableLogging) {
            Out-File -Filepath $this.LogFileFullName -Inputobject $Msg -Append -ErrorAction SilentlyContinue
        }
    } catch {
        $err = $_
        throw $err
    }
}
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name WriteToLog -Value $sbMethWriteToLog
$sbMethDisplayToScreen = {
    # Method to display to screen
    Param ([string[]] $Msg = '')
    if ($this.EnableDisplay) {
        Write-Host $Msg
    }
}
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name DisplayToScreen -Value $sbMethDisplayToScreen
$sbIsoDateLocal = {Get-Date -uformat "%Y-%m-%dT%T%Z"} # ISO 8601 format 2016-08-23T22:10:45+05
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name GetDateTime_Iso -Value $sbIsoDateLocal
$sbDtTodayUnderScr = {Get-Date -uformat "%Y-%m-%d_%I_%M_%S_%p"} # YYYY-MM-DD HH-MM-SS AM/PM  
Add-Member -InputObject $oMain -MemberType ScriptMethod -Name GetDateTime_UnderScr -Value $sbDtTodayUnderScr
function funcDownloadFileViaHttp( [string] $sFullNameDownload, [string] $sDestinationPath, [string] $sFileName = '' ) {
    <#  .DESCRIPTION
            Download a file via HTTP(s).  PS v2 compatible.
            This process will OVERWRITE a file with the same name in the destination
            Large file sizes and long download times are supported
        .PARAMETER sFullNameDownload
            Full name download location
        .PARAMETER sDestinationPath
            Destination path for the file after download
        .PARAMETER sFileName
            Override the automatically calculated file name in sFullNameDownload with this specified name.
        .OUTPUTS
            The destination file object
    #>
    $oHttpWebRequest = [System.Net.HttpWebRequest]::Create($sFullNameDownload)
    $oHttpWebRequest.KeepAlive = $true
    $oHttpWebResponse = $oHttpWebRequest.GetResponse()
    if ( $oHttpWebResponse.StatusCode.value__ -eq 200) {
        if ($sFileName -eq '') {
            $sFileName = $oHttpWebRequest.RequestUri.Segments[-1]
        } 
        $sFileFullNameFinal = @($sDestinationPath,'\',$sFileName) -join ''
        $oStream = $oHttpWebResponse.GetResponseStream()
        [byte[]] $buffer1 = New-Object byte[] 4096
        $oStreamDest = New-Object System.IO.FileStream ($sFileFullNameFinal,[IO.FileMode]::Create)
        do {
            # This process will OVERWRITE a file with the same name in the destination
            $iByteCountFilled = $oStream.Read($buffer1,0,($buffer1.Length))
            $oStreamDest.Write($buffer1,0,$iByteCountFilled)
        } while ($iByteCountFilled -ne 0)
        $oStreamDest.Close()
        $oStream.Close()
        $oStream.Dispose()
        $oFile = Get-Item $sFileFullNameFinal
    } else {
            throw 'Bad response from web server'
    }
    return ,$oFile
} # End of function funcDownloadFileViaHttp
function funcSearchUpdates-OutputAsSearchResults( [string] $sWsusscn2File, [bool] $bolIsInstalled ) {
    <#  .DESCRIPTION
            Run this on a workstation to check for required updates.
            Passing in fullname to local wsusscn2.cab file will cause the check to be local only.
            Otherwise it will use MS online updates to check. 
        .PARAMETER sWsusscn2File
            Full path to the wsusscn2.cab file
        .PARAMETER bolIsInstalled
            True = Get installed updates
            False = Get needed updates
        .OUTPUTS
            Windows Update SearcherResult object
        .NOTES
            Full search criteria list available https://msdn.microsoft.com/en-us/library/windows/desktop/aa386526(v=vs.85).aspx
    #>
    $bolUseOnlineSource = $false
    if ( [string]::IsNullOrEmpty($sWsusscn2File) ) {
        $bolUseOnlineSource = $true
    }
    # Define search criteria with optional updates
    if ( $bolIsInstalled ) {
        $sSearchCriteria = "IsInstalled=1 and Type='Software'"
    } else {
        $sSearchCriteria = "IsInstalled=0 and Type='Software'"
    }
    # Define search criteria without optional updates
    #$sSearchCriteria = "IsInstalled=0 and Type='Software' and BrowseOnly=0" # and IsAssigned=1"
    
    $oUpdateSession = New-Object -ComObject Microsoft.Update.Session
    $oSearcher = $oUpdateSession.CreateUpdateSearcher()
    if ( $bolUseOnlineSource ) {
        # To run an update search with online access.  Might work with WSUS also.
        $oSearcherResults = $oSearcher.Search($sSearchCriteria)  # Syncronous
    } else {
        $sOfflineServiceName = "Offline Sync Service"
        $oUpdateServiceManager = New-Object -ComObject Microsoft.Update.ServiceManager
        $oUpdateService = $oUpdateServiceManager.AddScanPackageService($sOfflineServiceName, $sWsusscn2File, 1)
        $oSearcher.ServerSelection = 3 # There are two existing (MS and WSUS)  We want the service number we just added
        $oSearcher.ServiceID = $oUpdateService.ServiceID
        $oSearcherResults = $oSearcher.Search($sSearchCriteria)  # Syncronous
    }
    return ,$oSearcherResults
}
function funcRemoveUpdateServiceManagerService( [string] $sServiceName = "Offline Sync Service" ) {
    $oUpdateServiceManager = New-Object -ComObject Microsoft.Update.ServiceManager
    $oUpdateServiceManager.Services | Where-Object { $_.Name -eq $sServiceName } | ForEach-Object {
        $oUpdateServiceManager.RemoveService($_.ServiceID)
    }
}
function funcDownloadWsusScn2FileToLocal() {
    <#  .DESCRIPTION
            Download the wsusscn2.cab file from the web server
        .PARAMETER sWsusscn2FileSrc
            Defined outside this function.  Full path to the wsusscn2.cab file on a web server
        .PARAMETER sWsusscn2FileDest
            Defined outside this function.  Full path to the wsusscn2.cab file
        .OUTPUTS
            Nothing.  File is copied to sWsusscn2FileDest.
        .NOTES
            Needs funcDownloadFileViaHttp and funcCreateFolderPath defined outside this function to be accessable
    #>
    # Test that everything is OK for the wsusscn2.cab path and file
    if ( Test-Path -PathType Leaf -Path $sWsusscn2FileDest ) {
        $sWsusscn2FolderDest = Split-Path -Parent $sWsusscn2FileDest
        $oWsusscn2FolderDest = Get-Item $sWsusscn2FolderDest
    } else {
        # File and path do not exist.  Need to create
        $sWsusscn2FolderDest = Split-Path -Parent $sWsusscn2FileDest
        $oWsusscn2FolderDest = funcCreateFolderPath $sWsusscn2FolderDest
    }
    $textOut1 = "{0}  {1} {2} Copying file from '{3}' to '{4}'" -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sWsusscn2FileSrc, $sWsusscn2FileDest)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    $oParsedUrl = [System.Uri] $sWsusscn2FileSrc
    $sFileName = $oParsedUrl.Segments[-1]
    # We want to overwrite the file every time because we don't know if it's newer, funcDownloadFileViaHttp handles overwrite
    #if ( Test-Path -PathType Leaf -Path $sWsusscn2FileDest ) {
    #    Remove-Item -Force -Confirm:$false -Path $sWsusscn2FileDest
    #}
    funcDownloadFileViaHttp $sWsusscn2FileSrc $oWsusscn2FolderDest.FullName | Out-Null
    $textOut1 = "{0}  {1} {2} Copying completed" -f `
        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
} # End funcDownloadWsusScn2FileToLocal
function funcStringIsNullOrWhitespace([string] $string) {
    if ($null -ne $string) { $string = $string.Trim() }
    return [string]::IsNullOrEmpty($string)
}
function funcCreateFolderPath( [string] $sPathIn ) {
    <#  .DESCRIPTION
             Create an entire Windows folder path one folder at a time
        .PARAMETER sPathIn
             String containing the full path to the folder.  
             Accepts local or remote servers.  
                C:\  C:\myfolder1   \\server\share  \\server\share\myfolder1
                '~'  '~\new1\new2'  (empty str)   '.'  '.\'  '.\new1\new2'
        .OUTPUTS
            Directory object of the last folder created
    #>
    if ( $sPathIn -eq '' ) {  # Empty string, get current path
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    if ( $sPathIn -eq '.' ) { # Current path only
        $oTempPath = Get-Item -Path (Get-Location -PSProvider Filesystem).ProviderPath -ErrorAction Stop
        return ,$oTempPath
    }
    # Check for illegal characters  / ? < > * | ' " { } ;   Allows  c:\  \\server
    $sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( ($sPathIn -match $regex1) -or (funcStringIsNullOrWhitespace $sPathIn) ) {
        $textOut1 = "Folder path '{0}' has illegal character(s)" -f @($sPathIn)
        throw [System.ArgumentException] $textOut1
    }
    if ( Test-Path -PathType Container -Path $sPathIn ) {
        $oTempPath = Get-Item -Path $sPathIn
        return ,$oTempPath
    }
    $oTempPath = New-Item -Path $sPathIn -Type Directory
    return ,$oTempPath
} # End funcCreateFolderPath
function funcValidateFilenameStringInput( [string] $sIn ) {
    # Check for illegal characters / ? < > * | ' " { } [] = ;
    $sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\[','\]','\=','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( $sIn -match $regex1 ) {
        $sError = "Input '{0}' has invlid character(s)" -f @($sIn)
        throw [System.ArgumentException] $sError  
    }
}
function funcExtractFilesFromCab( [System.IO.FileInfo] $oCabFile, 
                                  [array] $aFileNames, 
                                  [System.IO.DirectoryInfo] $oDestDir ) {
    <#  .DESCRIPTION
            Extract file(s) from a CAB file.  Tested on Win 7 and 2012R2
        .PARAMETER oCabFile
            File object, Source CAB file.  Must be pre-existing
        .PARAMETER aFileNames
            Array, Short file name(s) to be extracted from the cab file
        .PARAMETER oDestDir
            Directory object, Destination directory.  Must be pre-existing.
        .OUTPUTS
            Nothing
        .NOTES
            Requires funcValidateFilenameStringInput function be available
    #>
    funcValidateFilenameStringInput $oCabFile.FullName
    $aFileNames | ForEach-Object {
        $sFileName = [string] $_
        # FIX ME:  Need same validation input as the log file
        funcValidateFilenameStringInput $sFileName
        if ( Test-Path -PathType Leaf (Join-Path $oDestDir $sFileName) ) {
            Get-Item (Join-Path $oDestDir $sFileName) | Remove-Item -Force
        }
    }
    funcValidateFilenameStringInput $oDestDir.FullName
    if ( -not (Test-Path -PathType Leaf $oCabFile) ) {
        throw 'oCabFile needs to be an existing cab file object'
    }
    if ( -not (Test-Path -PathType Container $oDestDir) ) {
        throw 'oDestDir needs to be an existing directory object'
    }
    # expand.exe source.cab -F:Filename Destination
    $aFileNames | ForEach-Object {
        $sFileName = [string] $_
        $sExeTemp = @("expand.exe"," ",$oCabFile.FullName," ","-F:'",$sFileName,"' ",$oDestDir.FullName) -join ''
        $oResult = Invoke-Expression $sExeTemp
    }
}
function funcGetFileInsideCab() {
    $sTempFile = 'index.xml'
    $aFileNamesOut = @($sTempFile)
    $oWsusscn2FileDest = Get-Item $sWsusscn2FileDest
    $sTempDest = @($env:Temp,'\',$oMain.GetDateTime_UnderScr()) -join ''
    $oTempDest = funcCreateFolderPath -sPathIn $sTempDest
    funcExtractFilesFromCab -oCabFile $oWsusscn2FileDest -aFileNames $aFileNamesOut -oDestDir $oTempDest 
    return Get-ChildItem -Path $oTempDest -Filter $sTempFile
}

# Change switch paramater to boolean
if ( $UseOfflineDb.GetType().Name -eq 'SwitchParameter' ) {
    $a_temp = $UseOfflineDb.ToBool()
    Remove-Variable UseOfflineDb
    $UseOfflineDb = $a_temp    # Scoping should be wide enough
    Remove-Variable a_temp
} else { throw [System.ArgumentException] 'Input must be of type SwitchParameter' }
if ( $DownloadOfflineDb.GetType().Name -eq 'SwitchParameter' ) {
    $a_temp = $DownloadOfflineDb.ToBool()
    Remove-Variable DownloadOfflineDb
    $DownloadOfflineDb = $a_temp    # Scoping should be wide enough
    Remove-Variable a_temp
} else { throw [System.ArgumentException] 'Input must be of type SwitchParameter' }
if ( $ApplyUpdates.GetType().Name -eq 'SwitchParameter' ) {
    $a_temp = $ApplyUpdates.ToBool()
    Remove-Variable ApplyUpdates
    $ApplyUpdates = $a_temp    # Scoping should be wide enough
    Remove-Variable a_temp
} else { throw [System.ArgumentException] 'Input must be of type SwitchParameter' }

# l  Log file with full path.  This must be processes before -file
# Check for illegal characters / ? < > * | ' " { } ;
$sTemp = @('\/','\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
$regex1 = [regex] $sTemp
if ( $l -match $regex1 ) {
    throw [System.ArgumentException] 'Log file input has invlid character(s)' 
}
switch ( $l.ToLower() ) {
    '--' {
        $bolEnableLogging = $false
        $sLogFileFullNameFinal = $l
        break
    }
    'default' {
        # Logging is to be done to the default local temp directory
        $sExt = '.txt'
        $sDtTemp = Invoke-Command -ScriptBlock $sbDtTodayUnderScr
        $sLogFileFullNameFinal = @($sLogRoot,"\Log",'_',$env:computername,'_',$sDtTemp,$sExt) -join ''
        $bolEnableLogging = $true
        break
    }
    default {
        # We have some file to log to
        # The Split-Path auto handles the tailing \ on a directory 
        $sDirPath = Split-Path -Parent $l               # Log file Path only
        $sFileNameWExt = Split-Path -Leaf $l            # Log file Name with extention
        $sExt = '.txt'
        if ( $sFileNameWExt -match "(?<Extension>\.log$|\.txt$)" ) {
            $sFileName = $sFileNameWExt.Remove($sFileNameWExt.length - 4)
            $sExt = $matches.Extension
        } else {
            $sFileName = $sFileNameWExt
        }
        $sDtTemp = Invoke-Command -ScriptBlock $sbDtTodayUnderScr
        $sLogFileFullNameFinal = @($sDirPath,'\',$sFileName,'_',$env:computername,'_',$sDtTemp,$sExt) -join ''
        $bolEnableLogging = $true
        break
    }
}
Add-Member -InputObject $oMain -MemberType NoteProperty -Name LogFileFullName -Value $sLogFileFullNameFinal
Add-Member -InputObject $oMain -MemberType NoteProperty -Name EnableLogging -Value $bolEnableLogging
Add-Member -InputObject $oMain -MemberType NoteProperty -Name EnableDisplay -Value $bolEnableDisplayToScreen

################################ MAIN ################################
######################################################################
$oMain.WriteToLog($oMain.GetDateTime_Iso()+'  Test write to log')
$textOut1 = "Computer: {0}" -f @($oMain.CompName)
$oMain.DisplayToScreen($textOut1)
$oMain.WriteToLog($oMain.GetDateTime_Iso()+'  '+$textOut1)

if ( $DownloadOfflineDb ) {
    funcDownloadWsusScn2FileToLocal
}
function funcApplyUpdates() {
    funcRemoveUpdateServiceManagerService
    $textOut1 = "{0}  {1} {2} Determining which updates are needed" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);

    if ( $UseOfflineDb ) {
        if ( -not (Test-Path -PathType Leaf -Path $sWsusscn2FileDest) ) { 
            funcDownloadWsusScn2FileToLocal
        }
        # Get information about cab file for central record keeping and monitoring
        $oTempFile = funcGetFileInsideCab
        $oTempFile = $oTempFile | Select CompName,CabFile,@{Name='ExtractedFile'; Expression={$_.Name}},LastWriteTime,LastWriteTimeUtc
        $oTempFile.CabFile = Split-Path -Leaf -Path $sWsusscn2FileDest
        $oTempFile.CompName = $oMain.CompName
        if ( Test-Path -PathType Container -Path $sResultsRoot ) {
            $sTemp = @($sResultsRoot,'\','CabFileInformation-',$oMain.CompName,'_',$oMain.GetDateTime_UnderScr(),'.xml') -join ''
        } else {
            $sTemp = @($env:Temp,'\','CabFileInformation-',$oMain.CompName,'_',$oMain.GetDateTime_UnderScr(),'.xml') -join ''
        }
        Export-Clixml -Force -Confirm:$false -Depth 1 -InputObject $oTempFile -Path $sTemp
        $textOut1 = "{0}  {1} {2} Information about the cab file has been exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sTemp)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);        
        # Run Windows update via WUA  https://msdn.microsoft.com/en-us/library/windows/desktop/aa387290(v=vs.85).aspx
        $oUpdates = (funcSearchUpdates-OutputAsSearchResults -sWsusscn2File $sWsusscn2FileDest -bolIsInstalled $false).Updates
    } else {
        $oUpdates = (funcSearchUpdates-OutputAsSearchResults -bolIsInstalled $false).Updates # Will use MS online as the source
    }
    <#
    https://msdn.microsoft.com/en-us/library/windows/desktop/aa386099(v=vs.85).aspx       IUpdate interface
    https://msdn.microsoft.com/en-us/library/windows/desktop/aa386124(v=vs.85).aspx       IUpdateDownloadContentCollection interface
    Each update has a DownloadContents that contains the URL to get the download from MS.
    You cannot get at this information in Powershell, maybe C#, but all of the reference code is C++.
    The WUA takes the UniqueID of the update and checks the local WSUS server to get the local download link
    So if you only have a web server that mirrors updates exactly as download.windowsupdate.com 
    would provide, the downloader api fails because it will try talking WSUS before downloading anything.

    So how do you work around this if all you have is a webserver in the offline environment?
    Redirect the download.windowsupdate.com DNS and point it to your web server that mirrors the layout of download.windowsupdate.com
    #>
    # This allows us to keep specific updates instead of all returned from WUA.
    $oUpdatesFiltered = New-Object -ComObject Microsoft.Update.UpdateColl
    for ( $i=0; $i -lt $oUpdates.count; $i++ ) {
        # $_.InstallationBehavior.CanRequestUserInput
        #if ( $oUpdates.Item($i).Title -LIKE '*Security*' ) {
            if ( -not $oUpdates.Item($i).EulaAccepted ) {
                $oUpdates.Item($i).AcceptEula() 
            }
            $oUpdatesFiltered.Add($oUpdates.Item($i)) | Out-Null
        #}
    }
    $textOut1 = "{0}  {1} {2} Found {3} filtered updates needed" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oUpdatesFiltered.count)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    if ( $oUpdatesFiltered.count -eq 0 ) { return }

    $oUpdateSession = New-Object -ComObject Microsoft.Update.Session
    # Note: Trying a proxy server will not change any requirement for a WSUS server or DNS redirect
    # $oUpdateSession.WebProxy.Address = 'https://mysite.com/'
    $oDownloader = $oUpdateSession.CreateUpdateDownloader()
    $htUpdatesRequired = @{}
    $textOut1 = "{0}  {1} {2} Downloading each update.  This might take some time..." -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    foreach ( $oItem in $oUpdatesFiltered ) {
        if ( $oItem.IsDownloaded ) {
            continue
        }
        # Download each update individually so we can catch errors
        $oUpdateCollTemp = New-Object -ComObject Microsoft.Update.UpdateColl
        $oUpdateCollTemp.Add($oItem) | Out-Null
        $oDownloader.Updates = $oUpdateCollTemp
        $oDownloaderResult = $oDownloader.Download()
        $iRc = $oDownloaderResult.ResultCode
        if ( ($iRc -eq 4) -or ($iRc -eq 5) ) {
            $htUpdatesRequired.Set_Item($oItem.Identity.UpdateID,$oItem.Title)
            $textOut1 = "{0}  {1} {2} Download failed for update '{3}' '{4}'" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oItem.Identity.UpdateID, $oItem.Title)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
        }
    }
    if ( $htUpdatesRequired.count -gt 0 ) {
        if ( Test-Path -PathType Container -Path $sResultsRoot ) {
            $sTemp = @($sResultsRoot,'\','UpdatesThatFailedDownload-',$oMain.CompName,'_',$oMain.GetDateTime_UnderScr(),'.xml') -join ''
        } else {
            $sTemp = @($env:Temp,'\','UpdatesThatFailedDownload-',$oMain.CompName,'_',$oMain.GetDateTime_UnderScr(),'.xml') -join ''
        }
        Export-Clixml -Force -Confirm:$false -Depth 300 -InputObject $htUpdatesRequired -Path $sTemp
        $textOut1 = "{0}  {1} {2} Information about failed downloads has been exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sTemp)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    }
    $textOut1 = "{0}  {1} {2} Starting installation of updates" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oUpdatesFiltered.count)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);

    $oInstaller = $oUpdateSession.CreateUpdateInstaller()
    $oInstaller.Updates = $oUpdatesFiltered
    $oInstallResult = $oInstaller.Install()
    function funcRebootCompWithMessage() {
        if ( $Reboot -eq -1 ) {
            return # Reboot variable is the default so nothing to do.
        }
        if ( $oInstallResult.RebootRequired ) {
            $textOut1 = "{0}  {1} {2} A reboot is required to complete the installation, waiting {3} seconds before rebooting" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $Reboot)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            Invoke-Command -ScriptBlock {shutdown /f /r /t $Reboot}
        }
    }
    switch ($oInstallResult.ResultCode) { 
        2 { 
            $sTemp = "Succeeded"
            funcRebootCompWithMessage
        } 
        3 { 
            $sTemp = "Succeeded with Errors"
            funcRebootCompWithMessage
        } 
        4 { 
            $sTemp = "Failed"
        } 
        5 { 
            $sTemp = "Aborted"
        } 
        default { 
            $sTemp = "Not defined: '{0}'" -f @($oInstallResult.ResultCode)
        }
    } # End of switch
    $textOut1 = "{0}  {1} {2} Result of update installation: '{3}'" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sTemp)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
} # End funcApplyUpdates
try {
    if ( $ApplyUpdates ) {
        funcApplyUpdates
    }
}
catch {
    $err = $_
    switch ($err.Exception.Message.tostring()) {
        'Exception from HRESULT: 0x8024402C' {
            $textOutCust1 = 'Windows update is not enabled/could not reach update server.  Are you trying to search online or offline?'
            break
        }
        'Exception from HRESULT: 0x80072F8F' {
            $textOutCust1 = 'Windows update is not enabled/could not reach update server for Microsoft.  Are you trying to search online or offline?'
            break
        }
        'The digital signature of the object did not verify. (Exception from HRESULT: 0x80096010)' {
            $textOutCust1 = 'Verifiy that the cab file is valid.  Open in Explorer.  Then verify the certificates.'
            break
        }
        'The file type being saved or retrieved has been blocked. (Exception from HRESULT: 0x800700DE)' {
            $textOutCust1 = 'Verifiy that the cab file is valid.  Open in Explorer.  Then verify the certificates.'
            break
        }
        default {
            $textOutCust1 = ''
            break
        }
    }
    $textOut1 = "{0}  {1} {2} {3}" -f @($oMain.GetDateTime_Iso(), $oMain.ScriptName, 'Script failure!', $textOutCust1)
    $textOut2 = "$textOut1 `n{0}`nLine: {1}: {2}" -f `
                @($err.Exception.Message
                 ,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim()
                 ,$err.get_InvocationInfo().Line.Trim())
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut2)
    throw $err
}

function funcCheckForUpdate() {
    funcRemoveUpdateServiceManagerService
    # Some type of path passed to us.  Input could be c:\, \\servername, http://
    # Check for illegal characters ? < > * | ' " { } ;
    $sTemp = @('\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( $CheckForUpdates -match $regex1 ) {
        throw [System.ArgumentException] 'CheckForUpdates input has invlid character(s)'
    }
    switch ( $CheckForUpdates ) {
        'stdout' { # stdout requested by user
            Out-Null
            break 
        }
        'default' {
            if ( -not (Test-Path -PathType Container -Path $sResultsRoot) ) {
                funcCreateFolderPath $sResultsRoot | Out-Null
            } 
            $sTemp = @($sResultsRoot,'\','UpdatesNeeded-',$oMain.CompName,'.xml') -join ''
            if ( Test-Path -PathType Leaf -Path $sTemp ) {
                $oFile = Get-Item -Path $sTemp
                Remove-Item -Force -Confirm:$false -Path $oFile.FullName
            }
            $CheckForUpdates = $sTemp
            break
        }
        default {
            if ( Test-Path -PathType Container -Path $CheckForUpdates ) {
                throw [System.ArgumentException] 'CheckForUpdates input must be an XML file with path.'
            }
            if ( Test-Path -PathType Leaf -Path $CheckForUpdates ) {
                $oFile = Get-Item -Path $CheckForUpdates
                if ( $oFile.Extension -eq '.xml' ) {
                    Remove-Item -Force -Confirm:$false -Path $oFile.FullName
                } else {
                    throw [System.ArgumentException] 'CheckForUpdates export file exists and is not an XML file.'
                }
            }
            # Export destination file is non-existent so we can continue.
            # Make sure the folder path exists
            $sTempPath = Split-Path -Parent $CheckForUpdates
            funcCreateFolderPath $sTempPath | Out-Null
            break
        }
    } # End switch
    $textOut1 = "{0}  {1} {2} Determining which updates are needed" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    if ( $UseOfflineDb ) {
        if ( -not (Test-Path -PathType Leaf -Path $sWsusscn2FileDest) ) { 
            funcDownloadWsusScn2FileToLocal
        }
        # Get information about cab file for central record keeping and monitoring
        $oTempFile = funcGetFileInsideCab
        $oTempFile = $oTempFile | Select CompName,CabFile,@{Name='ExtractedFile'; Expression={$_.Name}},LastWriteTime,LastWriteTimeUtc
        $oTempFile.CabFile = Split-Path -Leaf -Path $sWsusscn2FileDest
        $oTempFile.CompName = $oMain.CompName
        if ( Test-Path -PathType Container -Path $sResultsRoot ) {
            $sTemp = @($sResultsRoot,'\','CabFileInformation-',$oMain.CompName,'_',$oMain.GetDateTime_UnderScr(),'.xml') -join ''
        } else {
            $sTemp = @($env:Temp,'\','CabFileInformation-',$oMain.CompName,'_',$oMain.GetDateTime_UnderScr(),'.xml') -join ''
        }
        Export-Clixml -Force -Confirm:$false -Depth 1 -InputObject $oTempFile -Path $sTemp
        $textOut1 = "{0}  {1} {2} Information about the cab file has been exported to '{3}'" -f `
                    @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $sTemp)
        $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);        
        # Run Windows update via WUA  https://msdn.microsoft.com/en-us/library/windows/desktop/aa387290(v=vs.85).aspx
        $oUpdates = (funcSearchUpdates-OutputAsSearchResults -sWsusscn2File $sWsusscn2FileDest -bolIsInstalled $false).Updates
    } else {
        $oUpdates = (funcSearchUpdates-OutputAsSearchResults -bolIsInstalled $false).Updates # Will use MS online as the source
    }
    $textOut1 = "{0}  {1} {2} Found {3} updates needed" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oUpdates.count)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    $htUpdatesRequired = @{}
    foreach ( $oItem in $oUpdates ) {
        $htUpdatesRequired.Set_Item($oItem.Identity.UpdateID,$oItem.Title)
    }
    switch ( $CheckForUpdates ) {
        'stdout' { # stdout requested by user
            $textOut1 = "{0}  {1} {2} Returning needed update results to stdout pipeline" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            return ,$htUpdatesRequired
            break 
        }
        # Don't need to worry about 'default' {} input here because $CheckForUpdates 
        # was assigned a file location when it was validated earlier.  The regular file handling
        # by this switch's default will handle this new value.
        default {
            $textOut1 = "{0}  {1} {2} Exporting needed updates results to '{3}'" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $CheckForUpdates)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            Export-Clixml -Depth 300 -InputObject $htUpdatesRequired -Path $CheckForUpdates
            break
        }
    } # End switch
}
try {
    # CheckForUpdates:  Param validation took care of null and 0 length for us already
    if ( $CheckForUpdates -ne "--" ) {
        funcCheckForUpdate
    } # End if
} # End $CheckForUpdates
catch {
    $err = $_
    switch ($err.Exception.Message.tostring()) {
        'Exception from HRESULT: 0x8024402C' {
            $textOutCust1 = 'Windows update is not enabled/could not reach update server.  Are you trying to search online or offline?'
            break
        }
        'Exception from HRESULT: 0x80072F8F' {
            $textOutCust1 = 'Windows update is not enabled/could not reach update server for Microsoft.  Are you trying to search online or offline?'
            break
        }
        'The digital signature of the object did not verify. (Exception from HRESULT: 0x80096010)' {
            $textOutCust1 = 'Verifiy that the cab file is valid.  Open in Explorer.  Then verify the certificates.'
            break
        }
        'The file type being saved or retrieved has been blocked. (Exception from HRESULT: 0x800700DE)' {
            $textOutCust1 = 'Verifiy that the cab file is valid.  Open in Explorer.  Then verify the certificates.'
            break
        }
        default {
            $textOutCust1 = ''
            break
        }
    }
    $textOut1 = "{0}  {1} {2} {3}" -f @($oMain.GetDateTime_Iso(), $oMain.ScriptName, 'Script failure!', $textOutCust1)
    $textOut2 = "$textOut1 `n{0}`nLine: {1}: {2}" -f `
                @($err.Exception.Message
                 ,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim()
                 ,$err.get_InvocationInfo().Line.Trim())
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut2)
    throw $err
}

function funcGetInstalledUpdates() {
    funcRemoveUpdateServiceManagerService
    function funcInstalledUpdatesObjectFactory() {
        $oReturned = New-Object -TypeName System.Management.Automation.PSObject
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'LastDeploymentChangeTime' -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'Title' -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'KBArticleIDs' -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'SecurityBulletinIDs' -Value $null
        #Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'SupersededUpdateIDs' -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'MoreInfoUrls' -Value $null
        Add-Member -InputObject $oReturned -MemberType NoteProperty -Name 'CompName' -Value $oMain.CompName
        return ,$oReturned
    } # End funcInstalledUpdatesObjectFactory
    # Some type of path passed to us.  Input could be c:\, \\servername, http://
    # Check for illegal characters ? < > * | ' " { } ;
    $sTemp = @('\?','\<','\>','\*','\|',"\'",'\"','\{','\}','\;') -join '|'
    $regex1 = [regex] $sTemp
    if ( $InstalledUpdates -match $regex1 ) {
        throw [System.ArgumentException] 'InstalledUpdates input has invlid character(s)'
    }
    switch ( $InstalledUpdates ) {
        'stdout' { # stdout requested by user
            Out-Null
            break 
        }
        'default' {
            if ( -not (Test-Path -PathType Container -Path $sResultsRoot) ) {
                funcCreateFolderPath $sResultsRoot | Out-Null
            } 
            $sTemp = @($sResultsRoot,'\','InstalledUpdates-',$oMain.CompName,'.xml') -join ''
            if ( Test-Path -PathType Leaf -Path $sTemp ) {
                $oFile = Get-Item -Path $sTemp
                Remove-Item -Force -Confirm:$false -Path $oFile.FullName
            }
            $InstalledUpdates = $sTemp
            break
        }
        default {
            if ( Test-Path -PathType Container -Path $InstalledUpdates ) {
                throw [System.ArgumentException] 'InstalledUpdates input must be an XML file with path.'
            }
            if ( Test-Path -PathType Leaf -Path $InstalledUpdates ) {
                $oFile = Get-Item -Path $InstalledUpdates
                if ( $oFile.Extension -eq '.xml' ) {
                    Remove-Item -Force -Confirm:$false -Path $oFile.FullName
                } else {
                    throw [System.ArgumentException] 'InstalledUpdates export file exists and is not an XML file.'
                }
            }
            # Export destination file is non-existent so we can continue.
            # Make sure the folder path exists
            $sTempPath = Split-Path -Parent $InstalledUpdates
            funcCreateFolderPath $sTempPath | Out-Null
            break
        }
    } # End switch
    $textOut1 = "{0}  {1} {2} Getting installed updates" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    if ( $UseOfflineDb ) {
        if ( -not (Test-Path -PathType Leaf -Path $sWsusscn2FileDest) ) { 
            funcDownloadWsusScn2FileToLocal
        }
        # Run Windows update via WUA  https://msdn.microsoft.com/en-us/library/windows/desktop/aa387290(v=vs.85).aspx
        $oUpdates = (funcSearchUpdates-OutputAsSearchResults -sWsusscn2File $sWsusscn2FileDest -bolIsInstalled $true).Updates
    } else {
        $oUpdates = (funcSearchUpdates-OutputAsSearchResults -bolIsInstalled $false).Updates # Will use MS online as the source
    }
    $textOut1 = "{0}  {1} {2} Found {3} installed updates" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oUpdates.count)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    $aOutputs = @()
    foreach ( $oItem in $oUpdates ) {
        $oSingleOutput = funcInstalledUpdatesObjectFactory
        $oSingleOutput.LastDeploymentChangeTime = $oItem.LastDeploymentChangeTime
        $oSingleOutput.Title = $oItem.Title
        $oSingleOutput.KBArticleIDs = $oItem.KBArticleIDs -join ' '
        $oSingleOutput.SecurityBulletinIDs = $oItem.SecurityBulletinIDs -join ' '
        #$oSingleOutput.SupersededUpdateIDs = $oItem.SupersededUpdateIDs -join ' '
        $oSingleOutput.MoreInfoUrls = $oItem.MoreInfoUrls -join ' '
        $aOutputs += $oSingleOutput
    }
    # Now the same idea for Hotfixes
    $oUpdates = Get-HotFix
    $textOut1 = "{0}  {1} {2} Found {3} installed hot fixes" -f `
                @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $oUpdates.count)
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
    foreach ( $oItem in $oUpdates ) {
        $oSingleOutput = funcInstalledUpdatesObjectFactory
        $oSingleOutput.LastDeploymentChangeTime = $oItem.InstalledOn
        $oSingleOutput.Title = $oItem.Description.Trim()
        $oSingleOutput.KBArticleIDs = $oItem.HotFixID.Replace('KB','').Trim()
        $oSingleOutput.SecurityBulletinIDs = ''
        $oSingleOutput.MoreInfoUrls = $oItem.Caption.Trim()
        $aOutputs += $oSingleOutput
    }
    switch ( $InstalledUpdates ) {
        'stdout' { # stdout requested by user
            $textOut1 = "{0}  {1} {2} Returning installed update results to stdout pipeline" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            return ,$aOutputs
            break 
        }
        # Don't need to worry about 'default' {} input here because $InstalledUpdates 
        # was assigned a file location when it was validated earlier.  The regular file handling
        # by this switch's default will handle this new value.
        default {
            $textOut1 = "{0}  {1} {2} Exporting installed updates results to '{3}'" -f `
                        @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName, $InstalledUpdates)
            $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);
            Export-Clixml -Depth 300 -InputObject $aOutputs -Path $InstalledUpdates
            break
        }
    } # End switch
}
try {
    # InstalledUpdates:  Param validation took care of null and 0 length for us already
    if ( $InstalledUpdates -ne "--" ) {
        funcGetInstalledUpdates
    } # End if
} # End $InstalledUpdates
catch {
    $err = $_
    switch ($err.Exception.Message.tostring()) {
        'Exception from HRESULT: 0x8024402C' {
            $textOutCust1 = 'Windows update is not enabled/could not reach update server.  Are you trying to search online or offline?'
            break
        }
        'Exception from HRESULT: 0x80072F8F' {
            $textOutCust1 = 'Windows update is not enabled/could not reach update server for Microsoft.  Are you trying to search online or offline?'
            break
        }
        'The digital signature of the object did not verify. (Exception from HRESULT: 0x80096010)' {
            $textOutCust1 = 'Verifiy that the cab file is valid.  Open in Explorer.  Then verify the certificates.'
            break
        }
        'The file type being saved or retrieved has been blocked. (Exception from HRESULT: 0x800700DE)' {
            $textOutCust1 = 'Verifiy that the cab file is valid.  Open in Explorer.  Then verify the certificates.'
            break
        }
        default {
            $textOutCust1 = ''
            break
        }
    }
    $textOut1 = "{0}  {1} {2} {3}" -f @($oMain.GetDateTime_Iso(), $oMain.ScriptName, 'Script failure!', $textOutCust1)
    $textOut2 = "$textOut1 `n{0}`nLine: {1}: {2}" -f `
                @($err.Exception.Message
                 ,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim()
                 ,$err.get_InvocationInfo().Line.Trim())
    $oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut2)
    throw $err
}

$textOut1 = "{0}  {1} {2} Script run complete" -f `
            @($oMain.GetDateTime_Iso(), $oMain.CompName, $oMain.ScriptName)
$oMain.DisplayToScreen($textOut1); $oMain.WriteToLog($textOut1);


