﻿# Set the UpdateID to search on.  Title is optional
$htUpdatesRequired = @{'myguidhere'='KB4025252'}

# Note: To get the information needed, you need to have the update approved and downloaded
# to the WSUS server.  You can uncomment the three lines below to have the update
# auto approved and downloaded (so think about it befor changing the line)

####################################################################################
Set-StrictMode -Version 2 -Verbose
$ErrorActionPreference = 'Stop'
function funcGetOnlyTheseWsusUpdates( [hashtable] $htUpdatesRequired ) {
    <#  .DESCRIPTION
            Get updates from WSUS based the UpdateID
        .PARAMETER htUpdatesRequired
            Hashtable, name is UpdateID guid, value is the update title which is a nice description for the user
        .OUTPUTS
            Array with individual update object or empty array
    #>
    $aReturned = @()
    $htUpdatesRequired.GetEnumerator() | ForEach-Object {
        $sUpdateId = $_.Name
        $sUpdateTitle = $_.Value
        $oSingleUpdate = $null
        try {
            # GetUpdate() takes only the update ID
            $oSingleUpdate = $oWsusServer.GetUpdate([guid]$sUpdateId)
        } catch {
            $err = $_
            $textOut1 = "Error: {0}, Line: {1}, {2}" -f `
                @($err.Exception.Message,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim(),$err.get_InvocationInfo().Line.Trim())
            Write-Host $textOut1
        }
        try {
            # SearchUpdates take everything EXCEPT update ID
            $oSingleUpdate = $oWsusServer.SearchUpdates($sUpdateTitle)
        } catch {
            $err = $_
            $textOut1 = "Error: {0}, Line: {1}, {2}" -f `
                @($err.Exception.Message,$err.get_InvocationInfo().ScriptLineNumber.ToString().Trim(),$err.get_InvocationInfo().Line.Trim())
            Write-Host $textOut1
        }
        $aReturned += $oSingleUpdate
    }
    return ,$aReturned
}
function funcGetUpdateFileListing( [array] $aUpdates ) {
    <#  .DESCRIPTION
            Get the individual files for the input updates
        .PARAMETER aUpdates
            Array of WSUS updates
        .OUTPUTS
            Array with individual files from each update, or an empty array
    #>
    $aFiles = @()
    $aUpdates | ForEach-Object {
        $oSingleUpdate = $_
        $aFiles += @( $oSingleUpdate.GetInstallableItems().Files | `
            Where-Object {($_.Type -eq 'SelfContained') -or 
                (($_.Type -eq 'None') -and ($_.IsEula -eq $False))  # Filter out Eula files from EXEs
            } | Select Name,FileUri,OriginUri,Type,Hash,AdditionalHash
        )
    }
    return ,$aFiles
}

$oWsusServer = Get-WsusServer
#[void][Reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration")
#$oWsusServer = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer()
$sWsusCacheFilePath = $oWsusServer.GetConfiguration().LocalContentCachePath
$aUpdates = funcGetOnlyTheseWsusUpdates $htUpdatesRequired

# This will approve for ALL COMPUTERS, accept EULA, and (if WSUS is set) download the update 
#$oAllComputersGroup = $oWsusServer.GetComputerTargetGroups() | Where-Object { $_.Name -eq 'All Computers'}
#$aUpdates | Where-Object { $_.RequiresLicenseAgreementAcceptance } | ForEach-Object { $_.AcceptLicenseAgreement() }
#$aUpdates | Where-Object { -not $_.IsApproved } | ForEach-Object { $_.ApproveForOptionalInstall($oAllComputersGroup) } | Out-Null

foreach ( $oEntry in $htUpdatesRequired.GetEnumerator() ) {
    Write-Host 'UpdateID: ' $oEntry.Name
    Write-Host 'Title: ' $oEntry.Value
}
$aWsusFiles = funcGetUpdateFileListing $aUpdates
$aWsusFiles | ForEach-Object {
    $oSingleUpdate = $_
    Write-Host 'WSUS local cache: ' $sWsusCacheFilePath
    Write-Host 'FileUri local: ' $oSingleUpdate.FileUri.LocalPath
    Write-Host 'OriginUri: ' $oSingleUpdate.OriginUri
}

